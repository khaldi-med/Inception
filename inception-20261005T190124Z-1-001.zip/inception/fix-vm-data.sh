#!/bin/sh
set -eu

# Repairs required host data directories for the Inception project:
#   /home/<login>/data/mariadb
#   /home/<login>/data/wordpress
#
# Usage:
#   ./fix-vm-data.sh
#   ./fix-vm-data.sh <login>

LOGIN_NAME="${1:-${SUDO_USER:-${USER:-}}}"

if [ -z "${LOGIN_NAME}" ]; then
	echo "Could not determine login name. Pass it explicitly: ./fix-vm-data.sh <login>" >&2
	exit 1
fi

if ! id "${LOGIN_NAME}" >/dev/null 2>&1; then
	echo "User '${LOGIN_NAME}' does not exist on this VM." >&2
	exit 1
fi

BASE_DIR="/home/${LOGIN_NAME}/data"
MARIADB_DIR="${BASE_DIR}/mariadb"
WORDPRESS_DIR="${BASE_DIR}/wordpress"

echo "[1/4] Creating data directories..."
mkdir -p "${MARIADB_DIR}" "${WORDPRESS_DIR}"

echo "[2/4] Fixing ownership to ${LOGIN_NAME}:${LOGIN_NAME}..."
if [ "$(id -u)" -eq 0 ]; then
	chown -R "${LOGIN_NAME}:${LOGIN_NAME}" "${BASE_DIR}"
else
	sudo chown -R "${LOGIN_NAME}:${LOGIN_NAME}" "${BASE_DIR}"
fi

echo "[3/4] Fixing directory permissions..."
chmod 755 "${BASE_DIR}" "${MARIADB_DIR}" "${WORDPRESS_DIR}"

echo "[4/4] Verifying write access..."
touch "${MARIADB_DIR}/.write_test" "${WORDPRESS_DIR}/.write_test"
rm -f "${MARIADB_DIR}/.write_test" "${WORDPRESS_DIR}/.write_test"

echo "Done. Data directories are ready:"
echo "  - ${MARIADB_DIR}"
echo "  - ${WORDPRESS_DIR}"
echo
echo "Next, run: make all"
