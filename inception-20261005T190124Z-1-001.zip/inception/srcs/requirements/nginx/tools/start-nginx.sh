#!/bin/sh
# ============================================================
# NGINX entrypoint — generate cert once, then exec nginx.
# ============================================================

set -eu

# .env must provide the domain
if [ -z "${DOMAIN_NAME:-}" ]; then
	echo "Missing required environment variable: DOMAIN_NAME" >&2
	exit 1
fi

# --- generate a self-signed cert ONLY if missing ---
# -s = exists and non-empty. Idempotent: container restarts reuse the cert.
# -x509      : self-signed certificate (no CA involved)
# -nodes     : private key WITHOUT password — nginx must read it at boot
#              without prompting (an encrypted key would hang on start)
# -newkey rsa:2048 : create key+cert in one shot
# -days 365  : valid one year (fine for a local training project)
# -subj      : identity fields; CN (Common Name) = our DOMAIN_NAME.
if [ ! -s /etc/ssl/private/inception.key ] || [ ! -s /etc/ssl/certs/inception.crt ]; then
	echo "[nginx] generating self-signed certificate for ${DOMAIN_NAME}..."
	openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
		-keyout /etc/ssl/private/inception.key \
		-out /etc/ssl/certs/inception.crt \
		-subj "/C=MA/ST=NA/L=NA/O=42/OU=Inception/CN=${DOMAIN_NAME}"
fi

# --- hand over to the real daemon ---
# -g "daemon off;" = stay in the FOREGROUND (containers need a live PID 1;
#   nginx's default behavior of forking into background would end the
#   container instantly). `exec` replaces this shell with nginx itself.
exec nginx -g "daemon off;"