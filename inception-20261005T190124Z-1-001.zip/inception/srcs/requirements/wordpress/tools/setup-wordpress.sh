#!/bin/sh
# ============================================================
# WordPress entrypoint — wait for DB, install WP once, exec FPM.
#
# Order matters (dependency chain of the whole stack):
#   1. WAIT for MariaDB (it may boot slower than us, depends_on is
#      not enough — it only means 'started', not 'ready')
#   2. Download WordPress + write wp-config.php  (uses DB creds)
#   3. Install: creates the DB tables + admin user
#   4. Create the second user (role author)
#   5. exec php-fpm  -> becomes PID 1, listens on 9000
#
# Idempotent: if wp-config.php exists we SKIP download/install.
# Without that guard, every container restart would re-run the install
# against an already-populated DB -> errors / data duplicates.
# ============================================================

set -eu

# --- guard for .env secrets ---
required_var() {
	name="$1"
	eval "value=\${$name:-}"
	if [ -z "$value" ]; then
		echo "Missing required environment variable: $name" >&2
		exit 1
	fi
}

required_var DOMAIN_NAME
required_var MYSQL_DATABASE
required_var MYSQL_USER
required_var MYSQL_PASSWORD
required_var WP_TITLE
required_var WP_ADMIN_USER
required_var WP_ADMIN_PASSWORD
required_var WP_ADMIN_EMAIL
required_var WP_USER
required_var WP_USER_PASSWORD
required_var WP_USER_EMAIL

# SUBJECT RULE: admin name must not contain the strings admin/administrator
if echo "$WP_ADMIN_USER" | grep -Eiq 'admin|administrator'; then
	echo "Invalid WP_ADMIN_USER: must not contain admin/administrator." >&2
	exit 1
fi

# --- 1. wait for the database ---
# mariadb-admin from the mariadb-client package; `-h mariadb` = Docker DNS,
# the container name on the 'inception' network resolves to its IP.
echo "[wp] waiting for MariaDB..."
until mariadb-admin ping -hmariadb -u"${MYSQL_USER}" -p"${MYSQL_PASSWORD}" --silent >/dev/null 2>&1; do
	sleep 2
done
echo "[wp] MariaDB is reachable."

mkdir -p /run/php /var/www/html

# --- 2+3. download & install ONLY if not already done ---
if [ ! -f /var/www/html/wp-config.php ]; then
	echo "[wp] installing WordPress..."

	# grabs the whole WordPress source tree (wp-admin, wp-includes, themes...)
	wp core download --path=/var/www/html --allow-root

	# writes wp-config.php from env vars.
	# --dbhost="mariadb:3306"  : again Docker DNS — not 127.0.0.1!
	# --skip-check             : don't spawn a DB check at this point;
	#                            (DB is already reachable anyway, and WP-CLI
	#                            would refuse without root mysql access at
	#                            the TCP level; safe + avoids a warning)
	wp config create \
		--path=/var/www/html \
		--dbname="${MYSQL_DATABASE}" \
		--dbuser="${MYSQL_USER}" \
		--dbpass="${MYSQL_PASSWORD}" \
		--dbhost="mariadb:3306" \
		--allow-root \
		--skip-check

	# creates all tables + the admin account in one shot.
	# --url must match DOMAIN_NAME (that's what NGINX serves)
	# --skip-email: no mail server exists in this stack, don't try to send
	wp core install \
		--path=/var/www/html \
		--url="https://${DOMAIN_NAME}" \
		--title="${WP_TITLE}" \
		--admin_user="${WP_ADMIN_USER}" \
		--admin_password="${WP_ADMIN_PASSWORD}" \
		--admin_email="${WP_ADMIN_EMAIL}" \
		--skip-email \
		--allow-root

	echo "[wp] core install done."
else
	echo "[wp] wp-config.php exists — skipping download/install."
fi

# --- 4. second user (only if not present) ---
if ! wp user get "${WP_USER}" --path=/var/www/html --allow-root >/dev/null 2>&1; then
	echo "[wp] creating user '${WP_USER}'..."
	wp user create "${WP_USER}" "${WP_USER_EMAIL}" \
		--path=/var/www/html \
		--user_pass="${WP_USER_PASSWORD}" \
		--role=author \
		--allow-root
fi

# --- ownership & handover ---
chown -R www-data:www-data /var/www/html /run/php

# -F (foreground): stay in front, don't daemonize. PID 1 = php-fpm.
exec php-fpm8.2 -F