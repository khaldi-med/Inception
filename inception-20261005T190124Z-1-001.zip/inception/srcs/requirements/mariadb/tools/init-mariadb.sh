#!/bin/sh
# ============================================================
# MariaDB entrypoint — bootstraps on FIRST run, then execs the daemon.
# Two phases, and this separation is THE key idea to understand:
#
#   PHASE 1 (first start only): /var/lib/mysql is empty
#     - create the system tables      (mariadb-install-db)
#     - start a TEMP server           (mysqld --skip-networking)
#     - create database + user + grants (via socket, no network!)
#     - shut the temp server down
#
#   PHASE 2 (every start, incl. restarts):
#     - exec mysqld  ->  mysqld becomes PID 1 and listens on 3306
#
# Idempotent: on restart /var/lib/mysql already has data -> phase 1 skipped.
# Also, without `exec`, our script would stay PID 1 as a shell and
# docker stop's SIGTERM would never reach the real mysqld. Exec fixes that.
# ============================================================

set -eu   # any error -> exit immediately (fail fast, easier to debug)

# --- guard: refuse to run without the secrets .env provides ---
required_var() {
	name="$1"
	eval "value=\${$name:-}"
	if [ -z "$value" ]; then
		echo "Missing required environment variable: $name" >&2
		exit 1
	fi
}

required_var MYSQL_DATABASE
required_var MYSQL_USER
required_var MYSQL_PASSWORD
required_var MYSQL_ROOT_PASSWORD

# runtime socket directory must exist & be owned by mysql
mkdir -p /run/mysqld
chown -R mysql:mysql /run/mysqld /var/lib/mysql

# --- PHASE 1: bootstrap only when the data dir is uninitialized ---
# The `mysql` subdirectory is created by mariadb-install-db; its absence
# means 'fresh volume' -> database.datadir sentinel trick.
if [ ! -d /var/lib/mysql/mysql ]; then
	echo "[init] fresh data dir — bootstrapping..."

	# Create the system DBs (mysql, performance_schema, ...) as user mysql
	mariadb-install-db --user=mysql --datadir=/var/lib/mysql >/dev/null

	# Temp server: --skip-networking = NO TCP port. During setup we must not
	# expose anything to the network — an attacker would see passwords fly.
	# Communication happens only via the unix socket below.
	# IMPORTANT: run it in BACKGROUND (&) so we can issue SQL via the client.
	mysqld --user=mysql --datadir=/var/lib/mysql --skip-networking \
		--socket=/run/mysqld/mysqld.sock &
	temp_pid="$!"   # remember it to wait for it at the end

	# Wait until the temp server answers on the socket (poll every 1s).
	until mariadb-admin --socket=/run/mysqld/mysqld.sock ping >/dev/null 2>&1; do
		sleep 1
	done

	# Create DB + app user + grants.
	# Never connect root to TCP; socket = same host only.
	mariadb --socket=/run/mysqld/mysqld.sock <<-SQL
		ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASSWORD}';
		CREATE DATABASE IF NOT EXISTS \`${MYSQL_DATABASE}\`;
		CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'%' IDENTIFIED BY '${MYSQL_PASSWORD}';
		GRANT ALL PRIVILEGES ON \`${MYSQL_DATABASE}\`.* TO '${MYSQL_USER}'@'%';
		FLUSH PRIVILEGES;
	SQL

	# Gracefully stop the temp server (shutdown via socket with root creds),
	# then wait so the wrapper shell doesn't linger.
	mariadb-admin --socket=/run/mysqld/mysqld.sock -uroot -p"${MYSQL_ROOT_PASSWORD}" shutdown
	wait "$temp_pid"
	echo "[init] bootstrap done."
else
	echo "[init] data dir already initialized — skipping setup."
fi

# --- PHASE 2: hand over to the real daemon (PID 1, port 3306 open) ---
# --console = logs to stdout so `docker logs` shows them.
exec mysqld --user=mysql --console