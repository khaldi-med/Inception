# USER_DOC.md – User Documentation

## Overview

This document explains how to start, stop, and manage the Inception WordPress stack, and how to access the website and administration panel.

---

## Services Provided

The Inception stack provides:

- **WordPress Website**: A fully functional WordPress installation accessible via HTTPS
- **Database Backend**: MariaDB database for WordPress content, users, and configuration
- **Web Gateway**: NGINX reverse proxy handling all incoming HTTPS traffic

---

## Quick Start

### 1. Start the Stack

```bash
cd ~/inception
make all
```

This command:
- Creates required data directories (`/home/$USER/data/mariadb`, `/home/$USER/data/wordpress`)
- Builds Docker images
- Starts three containers (mariadb, wordpress, nginx)
- Applies restart policy (containers auto-restart after failure or reboot)

**First startup takes 2–5 minutes** while databases initialize and WordPress is installed.

### 2. Verify Services Are Running

```bash
make ps
```

Expected output (all three containers running):
```
CONTAINER ID   IMAGE      COMMAND              STATUS
xxxxxxxx       mariadb    "/usr/local/bin/..." Up X seconds
xxxxxxxx       wordpress  "/usr/local/bin/..." Up X seconds
xxxxxxxx       nginx      "/usr/local/bin/..." Up X seconds
```

### 3. Access the Website

Open a browser and navigate to:
```
https://yourlogin.42.fr
```

**Security Warning**: The certificate is self-signed. Your browser will warn you. Click **Advanced** → **Proceed** (or equivalent for your browser).

---

## Admin Access

### Login to WordPress Admin Panel

1. Go to: `https://yourlogin.42.fr/wp-admin`
2. Log in with your **admin user** credentials (from `.env`):
   - **Username**: `WP_ADMIN_USER` (default: `siteowner42`)
   - **Password**: `WP_ADMIN_PASSWORD`

### Dashboard Features

- **Posts**: Create, edit, publish blog posts
- **Pages**: Manage static pages
- **Users**: View and manage registered users
- **Settings**: Configure site title, tagline, timezone, etc.
- **Plugins/Themes**: Install and activate plugins and themes

---

## Managing Services

### Check Service Status

```bash
make ps
```

### View Live Logs

```bash
make logs
```

To exit logs: Press `Ctrl+C`

### Stop Services (Keep Data)

```bash
make down
```

Containers stop, volumes persist. Data is safe.

### Restart Services

```bash
make all
```

Containers restart with preserved database and WordPress files.

### Clean Stop (Remove Containers & Images)

```bash
make clean
```

- Stops all containers
- Removes images (rebuilds on next `make all`)
- **Volumes persist** – your data is safe

### Full Reset (Remove Everything Including Data)

```bash
make fclean
```

⚠️ **WARNING**: This deletes all data, including the WordPress database and uploaded files. Use only if you want a complete fresh start.

### Restart Everything from Scratch

```bash
make re
```

Equivalent to `make fclean` followed by `make all`. Full reset + rebuild.

---

## Access WordPress Users

### Admin User (Site Owner)
- **Username**: Configured in `srcs/.env` (default: `siteowner42`)
- **Password**: `WP_ADMIN_PASSWORD`
- **Role**: Administrator (full access)
- **Use**: Site management, theme/plugin installation, user management

### Secondary User (Contributor/Author)
- **Username**: Configured in `srcs/.env` (default: `learner42`)
- **Password**: `WP_USER_PASSWORD`
- **Role**: Author (can create/edit own posts, upload media)
- **Use**: Content creation without admin privileges

### Add More Users

In WordPress Admin:
1. Go to **Users** → **Add New**
2. Fill in username, email, password
3. Assign role (Subscriber, Contributor, Author, Editor, Administrator)
4. Click **Add New User**

---

## Database Access

### Via WordPress
WordPress automatically connects to MariaDB. No manual database access needed for normal usage.

### Direct Database Access (Advanced)

```bash
docker exec -it mariadb mariadb -u root -p
```

Enter the root password when prompted (from `MYSQL_ROOT_PASSWORD` in `.env`).

Common commands:
```sql
SHOW DATABASES;
USE wordpress;
SHOW TABLES;
SELECT user_login, user_email FROM wp_users;
EXIT;
```

---

## Credentials Location

All credentials are stored in: `~/inception/srcs/.env`

**Never share this file or commit it to Git!**

File contents (example):
```env
DOMAIN_NAME=yourlogin.42.fr
MYSQL_ROOT_PASSWORD=secret
MYSQL_PASSWORD=secret
WP_ADMIN_PASSWORD=secret
WP_USER_PASSWORD=secret
```

To update credentials:
1. Edit `~/inception/srcs/.env`
2. Run `make re` (full restart required)

---

## Troubleshooting

### Services Won't Start

Check logs:
```bash
make logs
```

Common issues:
- **Port 443 in use**: Another service on HTTPS; stop it or change NGINX port
- **Data directory permissions**: Run `sudo chown -R $USER /home/$USER/data`
- **Time sync issue**: Ensure VM time is correct

### WordPress Not Loading

```bash
make ps
```

Verify all three containers are running. If WordPress or MariaDB is restarting:
```bash
make logs
```

Common causes:
- MariaDB init failed (check credentials in `.env`)
- WordPress initialization incomplete (wait 2–3 minutes on first start)

### Can't Log In

- Check `.env` for correct username/password
- Ensure database is running: `make ps`
- Clear browser cache and try again

### SSL Certificate Warnings

This is expected with self-signed certificates. Proceed anyway in your browser. In production, use a proper certificate from a Certificate Authority.

---

## Data Persistence

Your data is stored in:
- **Database**: `/home/$USER/data/mariadb/`
- **WordPress Files**: `/home/$USER/data/wordpress/`

These directories persist even after `make down` or `make clean`. To back up, copy these folders:
```bash
cp -r /home/$USER/data ~/backup-inception-data
```

---

## Reboot Behavior

After a VM reboot:
```bash
cd ~/inception
make all
```

Services will auto-restart due to the `restart: always` policy. Data and website remain intact.

---

## Need Help?

Refer to:
- **Developer Setup**: See `DEV_DOC.md`
- **Project Overview**: See `README.md`
- **WordPress Help**: https://wordpress.org/support/
- **NGINX Troubleshooting**: https://nginx.org/en/docs/
- **MariaDB Help**: https://mariadb.com/docs/
