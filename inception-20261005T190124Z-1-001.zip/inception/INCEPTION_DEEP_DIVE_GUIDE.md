# Inception Project — Deep Dive Guide

> A step-by-step, real-scenario explanation of **every file and concept** in the 42 Inception project.
> Written for a learner who wants to truly understand, not just copy-paste.

---

## Table of Contents

1. [The Mission — What Are We Building?](#1-the-mission--what-are-we-building)
2. [Architecture Overview — The Big Picture](#2-architecture-overview--the-big-picture)
3. [Project Directory Structure](#3-project-directory-structure)
4. [Layer 1: The Makefile (Your Control Panel)](#4-layer-1-the-makefile-your-control-panel)
5. [Layer 2: Docker Compose (The Orchestra Conductor)](#5-layer-2-docker-compose-the-orchestra-conductor)
6. [Layer 3: The .env File (The Key Vault)](#6-layer-3-the-env-file-the-key-vault)
7. [Service A: MariaDB (The Database)](#7-service-a-mariadb-the-database)
8. [Service B: WordPress + PHP-FPM (The Application)](#8-service-b-wordpress--php-fpm-the-application)
9. [Service C: NGINX (The Gatekeeper)](#9-service-c-nginx-the-gatekeeper)
10. [How It All Starts Up — A Real Scenario](#10-how-it-all-starts-up--a-real-scenario)
11. [What Happens When Something Crashes](#11-what-happens-when-something-crashes)
12. [Critical Rules Explained (Why the Subject Forbids X)](#12-critical-rules-explained-why-the-subject-forbids-x)
13. [What You Need to Do Next](#13-what-you-need-to-do-next)
14. [Common Pitfalls & How to Debug](#14-common-pitfalls--how-to-debug)

---

## 1. The Mission — What Are We Building?

### In One Sentence

You are building a **miniature, containerized web infrastructure** on a Virtual Machine that hosts a WordPress website powered by MariaDB and served through NGINX with HTTPS.

### Real-World Analogy

Imagine you're setting up a **small office building**:

| Component | Office Analogy | In Our Project |
|-----------|----------------|----------------|
| **NGINX** | The **receptionist + security guard** at the front door. Only they talk to the outside world. They check IDs (TLS/SSL) and route visitors to the right department. | The only service exposed to the internet (port 443). Handles all HTTPS traffic and proxies requests to WordPress. |
| **WordPress** | The **office workers** who actually do the work — creating web pages, handling user logins, writing blog posts. They don't talk to visitors directly. | PHP-FPM processes that run WordPress. They generate dynamic web pages. |
| **MariaDB** | The **filing cabinet / database room** where all documents (posts, user accounts, settings) are stored. | A MariaDB database server that stores all WordPress data persistently. |
| **Docker Network** | The **hallways** connecting the rooms. Services find each other by name (like room numbers). | A custom bridge network named `inception` where containers communicate. |
| **Docker Volumes** | The **basement storage** that survives even if you remodel the offices. Data lives here permanently. | Named volumes mapped to `/home/$LOGIN/data/` that persist database and website files. |

### Why This Matters

In real companies, this is how modern applications are deployed:
- **Microservices**: Each component (web server, app, database) runs in its own isolated container
- **Scalability**: You can run 10 WordPress containers behind 1 NGINX if traffic grows
- **Resilience**: If WordPress crashes, the database is still safe. If the whole server dies, your volumes still have the data
- **Reproducibility**: Anyone with these files can build the exact same infrastructure

---

## 2. Architecture Overview — The Big Picture

```
                          INTERNET
                             │
                    HTTPS (port 443)
                             │
                     ┌───────▼───────┐
                     │    NGINX      │  ◄── Only entry point
                     │  (TLS 1.2/3) │      Self-signed SSL cert
                     │  Reverse Proxy│
                     └───────┬───────┘
                             │ FastCGI on port 9000
                     ┌───────▼───────┐
                     │  WordPress +  │  ◄── Application layer
                     │   PHP-FPM     │      Generates dynamic pages
                     │   9000        │
                     └───────┬───────┘
                             │ TCP on port 3306
                     ┌───────▼───────┐
                     │   MariaDB     │  ◄── Data layer
                     │   3306        │      Stores everything
                     └───────────────┘

  All three containers are on the same Docker network: "inception"
  They talk to each other using service names: "nginx", "wordpress", "mariadb"
```

### Key Design Decision: Only NGINX is Externally Visible

- **Port 443** (HTTPS) is the **only port mapped to the host**
- WordPress (port 9000) and MariaDB (port 3306) are **internal only**
- This is a security best practice: minimize attack surface
- If someone hacks your network, they can't directly reach your database

---

## 3. Project Directory Structure

```
inception/                          # Root of your project
│
├── Makefile                        # Orchestrator: build, run, stop, clean
├── .gitignore                      # What not to commit (secrets, .env)
├── README.md                       # Project overview (for evaluators)
├── USER_DOC.md                     # End-user guide
├── DEV_DOC.md                      # Developer guide
├── SCHOOL_VM_SETUP.md              # VM bootstrap instructions
├── IMPLEMENTATION_SUMMARY.md        # What's done vs what's left
├── INCEPTION_DEEP_DIVE_GUIDE.md    # This file
│
└── srcs/                           # All source files for the stack
    ├── .env                        # Environment variables (SECRET — never commit)
    ├── .env.example                # Template for .env (safe to commit)
    ├── docker-compose.yml          # Defines all services, network, volumes
    │
    └── requirements/               # One subfolder per service
        ├── mariadb/                # Database service
        │   ├── Dockerfile          # How to build the MariaDB image
        │   ├── conf/
        │   │   └── 50-server.cnf   # MariaDB server configuration
        │   ├── tools/
        │   │   └── init-mariadb.sh  # Startup script (init DB + run server)
        │   └── .dockerignore       # What to exclude when building
        │
        ├── wordpress/              # Application service
        │   ├── Dockerfile          # How to build the WordPress image
        │   ├── conf/
        │   │   └── www.conf        # PHP-FPM pool configuration
        │   ├── tools/
        │   │   └── setup-wordpress.sh  # Startup script (install WP + run FPM)
        │   └── .dockerignore
        │
        └── nginx/                  # Web gateway service
            ├── Dockerfile          # How to build the NGINX image
            ├── conf/
            │   └── default.conf    # NGINX server configuration
            ├── tools/
            │   └── start-nginx.sh  # Startup script (SSL cert + run NGINX)
            └── .dockerignore
```

---

## 4. Layer 1: The Makefile (Your Control Panel)

**File**: `Makefile`

### What It Does

The Makefile is your **command center**. It translates simple commands (`make all`, `make logs`) into the complex Docker commands needed to manage the infrastructure.

### Real Scenario

You're a sysadmin. You walk into the office and want to restart the whole stack after a power outage. You type:

```bash
make re
```

That's **one command** that does all of this:
1. Deletes all data (`sudo rm -rf /home/$USER/data/*`)
2. Stops and removes containers, images, volumes
3. Rebuilds all three Docker images from scratch
4. Creates fresh data directories
5. Starts everything in the correct order

Without the Makefile, you'd have to type 10+ Docker commands and remember the right flags.

### Line-by-Line Explanation

```makefile
COMPOSE_FILE := srcs/docker-compose.yml
ENV_FILE := srcs/.env
```
- Defines variables so we don't repeat paths
- `:=` means "evaluate once" (Make syntax)

```makefile
COMPOSE_CMD := $(shell if docker compose version >/dev/null 2>&1; then echo "docker compose"; else echo "docker-compose"; fi)
```
- **Smart detection**: Modern Docker has `docker compose` (plugin), older systems have `docker-compose` (standalone binary)
- `docker compose version >/dev/null 2>&1` silently checks if the plugin exists
- If yes → uses `docker compose`, otherwise falls back to `docker-compose`
- This is a real-world concern: school VMs might have either version

```makefile
.PHONY: all up down clean fclean re logs ps
```
- Tells Make these are **commands** (targets), not actual files
- Without `.PHONY`, if a file named `all` existed, Make would think "nothing to do"

```makefile
up:
	mkdir -p /home/$(USER)/data/mariadb /home/$(USER)/data/wordpress
	$(COMPOSE_CMD) -f $(COMPOSE_FILE) --env-file $(ENV_FILE) up -d --build
```
- **Step 1**: Creates the host directories for persistent data
- `mkdir -p` creates parent directories if needed, won't error if they exist
- `/home/$(USER)/data/` — this is a project requirement: data lives at this path
- **Step 2**: `up -d --build`
  - `-d` = detached mode (run in the background)
  - `--build` = rebuild images before starting (picks up code changes)
  - Without `--build`, Docker would use the old cached images

```makefile
clean: down
	...down --rmi local --volumes --remove-orphans
```
- **Dependency**: `clean` first runs `down` (stops containers)
- `--rmi local` = remove locally-built images (not pulled ones)
- `--volumes` = remove named volumes (careful — this deletes data!)
- `--remove-orphans` = clean up containers not defined in compose file

```makefile
fclean: clean
	sudo rm -rf /home/$(USER)/data/mariadb /home/$(USER)/data/wordpress
```
- `fclean` = "full clean"
- Needs `sudo` because Docker owns those files (created as root inside containers)
- This is the nuclear option — deletes everything including your database

```makefile
re: fclean all
```
- "Re-do" = full reset then build
- Most reliable way to get a clean state

---

## 5. Layer 2: Docker Compose (The Orchestra Conductor)

**File**: `srcs/docker-compose.yml`

### What It Does

Docker Compose is a **declarative configuration file** that defines your entire infrastructure:
- What containers to run
- How to build them
- How they connect (network)
- Where data lives (volumes)
- What order to start them (dependencies)

### Real-World Analogy

Think of Docker Compose like an **architect's blueprint**. You give the blueprint to a builder (Makefile + Docker), and they construct the exact building (your infrastructure) every time.

### Line-by-Line Explanation

```yaml
version: "3.8"
```
- Compose file format version. 3.8 is widely supported.
- This defines what features are available (e.g., `restart: always` requires v3+).

### The Three Services

#### MariaDB
```yaml
mariadb:
    image: mariadb
    container_name: mariadb
    build:
      context: ./requirements/mariadb
```
- `image: mariadb` — the built image will be named `mariadb`
- `container_name: mariadb` — the running container will be named `mariadb`
- `build.context` — Docker will look in `srcs/requirements/mariadb/` for the Dockerfile

```yaml
    env_file:
      - .env
```
- Injects all variables from `.env` into the container as environment variables
- WordPress can then read `MYSQL_PASSWORD` from its environment

```yaml
    networks:
      - inception
```
- Connects this container to the `inception` bridge network
- This is how `wordpress` can reach `mariadb` just by hostname `mariadb`

```yaml
    volumes:
      - mariadb_data:/var/lib/mysql
```
- Mounts the named volume `mariadb_data` to `/var/lib/mysql` (MariaDB's data directory)
- **Inside the container**, `/var/lib/mysql` is where MariaDB stores databases
- **On the host**, this maps to `/home/$LOGIN/data/mariadb/` (defined in the volumes section at the bottom)

```yaml
    restart: always
```
- If the container crashes or the Docker daemon restarts, it comes back up
- Meets the subject requirement: "Your containers have to restart in case of a crash"

#### WordPress
```yaml
wordpress:
    image: wordpress
    container_name: wordpress
    build:
      context: ./requirements/wordpress
    env_file:
      - .env
    networks:
      - inception
    volumes:
      - wordpress_data:/var/www/html
    depends_on:
      - mariadb
    restart: always
```
- **Key difference**: `depends_on: - mariadb`
- This tells Docker: "Start MariaDB before WordPress"
- However, `depends_on` only waits for the container to **start**, not for the database to be **ready**
- The WordPress startup script handles the "wait for DB to be ready" part

#### NGINX
```yaml
nginx:
    image: nginx
    container_name: nginx
    build:
      context: ./requirements/nginx
    env_file:
      - .env
    networks:
      - inception
    volumes:
      - wordpress_data:/var/www/html:ro
    depends_on:
      - wordpress
    ports:
      - "443:443"
    restart: always
```
- **Key difference**: `ports: - "443:443"`
- Maps host port 443 to container port 443
- This is the **only** port exposed to the outside world
- `:ro` after the volume mount means **read-only** — NGINX can serve files but can't modify WordPress code
- `depends_on: - wordpress` ensures WordPress starts before NGINX

### The Network

```yaml
networks:
  inception:
    name: inception
```
- Creates a **bridge network** named `inception`
- Bridge networks give containers:
  - **Isolated environment** (not directly accessible from host)
  - **Automatic DNS** (containers can reach each other by service name)
  - Example: WordPress connects to `mariadb:3306` — Docker resolves `mariadb` to the container's IP

### The Volumes

```yaml
volumes:
  mariadb_data:
    name: mariadb_data
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /home/${LOGIN}/data/mariadb
  wordpress_data:
    name: wordpress_data
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /home/${LOGIN}/data/wordpress
```

This is the **most subtle part** of the whole project. Let me explain carefully.

#### What the Subject Demands

> "You must use Docker **named volumes** for these two persistent storages. Bind mounts are **not allowed** for these volumes."
> "Both named volumes must store their data inside `/home/login/data` on the host machine."

#### The Trick: Named Volume + Bind Mount Driver

Docker has two ways to persist data:

| Feature | Named Volume | Bind Mount |
|---------|-------------|------------|
| How it works | Docker manages a folder in `/var/lib/docker/volumes/` | You specify an exact host path |
| Subject allows? | ✅ Required | ❌ Not allowed for these volumes |
| Can you choose the path? | ❌ Defaults to `/var/lib/docker/volumes/<name>/_data` | ✅ You pick the path |

**The subject says**: named volumes are required AND data must be at `/home/login/data/...`.

Normally, named volumes live in `/var/lib/docker/volumes/`. You can't choose their path. But...

#### The Solution

We create a **named volume** but configure it with a **bind mount driver option**. This is still a named volume (Docker manages it), but the data actually lives at our chosen path:

- `type: none` — no special filesystem type (bind mount)
- `o: bind` — bind mount option
- `device: /home/${LOGIN}/data/mariadb` — the host path

Docker treats this as a named volume (can be managed with `docker volume` commands), but the data is stored at your specified path. This satisfies both requirements.

**Important**: The directory `/home/${LOGIN}/data/mariadb` must exist on the host **before** Docker tries to mount it. That's why the Makefile's `up` target creates them with `mkdir -p`.

---

## 6. Layer 3: The .env File (The Key Vault)

**File**: `srcs/.env`

### What It Does

Stores all configuration values and secrets that vary between deployments. Instead of hardcoding "mohkhald.42.fr" in a config file, you put it in `.env` and reference `${DOMAIN_NAME}` everywhere.

### Real Scenario

You're deploying this project for peer evaluation. The evaluator will:
1. Clone your repo
2. Run `cp srcs/.env.example srcs/.env`
3. Edit it with **their** login and passwords
4. Run `make all`

Without `.env`, they'd have to edit every config file individually. With `.env`, they change one file.

### Variable Breakdown

```
# Identity
LOGIN=mohkhald                    # Your 42 login / system username
DOMAIN_NAME=mohkhald.42.fr        # Your project domain (must be <login>.42.fr)

# Database credentials (used by MariaDB init and WordPress connection)
MYSQL_DATABASE=wordpress          # Name of the WordPress database
MYSQL_USER=wpuser                 # Database user (WordPress connects as this user)
MYSQL_PASSWORD=change_me          # Password for the database user
MYSQL_ROOT_PASSWORD=change_me_root # Root password (admin access to DB)

# WordPress site settings
WP_TITLE=Inception                # Title of your WordPress site
WP_ADMIN_USER=siteowner42         # Admin username (MUST NOT contain "admin"/"administrator")
WP_ADMIN_PASSWORD=change_me_admin # Admin password
WP_ADMIN_EMAIL=admin@example.com  # Admin email

# Second WordPress user (non-admin)
WP_USER=learner42                 # Secondary username
WP_USER_PASSWORD=change_me_user   # Secondary user password
WP_USER_EMAIL=learner@example.com # Secondary user email
```

### Security Notes

- **Never commit `.env` to Git** — it's in `.gitignore` for this reason
- **If you commit passwords to Git**, you fail the project
- Use strong passwords (the subject suggests "It is strongly recommended that you use Docker secrets")

### Why Two Database Variables?

`MYSQL_USER` / `MYSQL_PASSWORD` vs `MYSQL_ROOT_PASSWORD`:
- `root` is the super-admin (can create/drop databases, manage users)
- `wpuser` has access **only** to the `wordpress` database
- WordPress uses `wpuser` for day-to-day operations
- `root` is only used for initial setup and emergency admin access
- This is the **principle of least privilege**: each component gets only the permissions it needs

---

## 7. Service A: MariaDB (The Database)

### Dockerfile

**File**: `srcs/requirements/mariadb/Dockerfile`

```dockerfile
FROM debian:bookworm-slim
```

- We use **Debian**, not Alpine
- `bookworm` is the current stable release name
- `-slim` is a smaller variant (removes docs, locales, etc.)
- The subject says: "penultimate stable version" — Alpine 3.19 or Debian bookworm
- We deliberately **do not** use `:latest` (that's forbidden)

```dockerfile
RUN apt-get update \
    && apt-get install -y --no-install-recommends mariadb-server \
    && rm -rf /var/lib/apt/lists/*
```
- `--no-install-recommends` installs only the **minimum** dependencies
- `rm -rf /var/lib/apt/lists/*` removes the apt package cache
- **Why?** Smaller image size. Each `RUN` instruction creates a new Docker layer. By cleaning up in the **same** `RUN` command, the cache doesn't get saved in the layer.

```dockerfile
COPY conf/50-server.cnf /etc/mysql/mariadb.conf.d/50-server.cnf
COPY tools/init-mariadb.sh /usr/local/bin/init-mariadb.sh
```
- Copies our custom config and startup script into the image

```dockerfile
RUN chmod +x /usr/local/bin/init-mariadb.sh \
    && mkdir -p /run/mysqld \
    && chown -R mysql:mysql /run/mysqld /var/lib/mysql
```
- Makes the script executable
- Creates the MySQL socket directory (`/run/mysqld`)
- Ownership: the `mysql` user (not root) runs the database

```dockerfile
EXPOSE 3306
```
- **Documentation only**: tells humans "this container listens on port 3306"
- Does NOT actually publish the port (that's done in `docker-compose.yml`)

```dockerfile
ENTRYPOINT ["/usr/local/bin/init-mariadb.sh"]
```
- When the container starts, it runs this script
- The script runs as **PID 1** (the first process)
- **Crucial**: The script must end with `exec` so the main process takes over PID 1

### Configuration: 50-server.cnf

**File**: `srcs/requirements/mariadb/conf/50-server.cnf`

```ini
[mysqld]
bind-address = 0.0.0.0
port = 3306
skip-name-resolve
```

- `bind-address = 0.0.0.0` — listen on **all** network interfaces (not just localhost)
  - **Necessary** because WordPress connects from another container
  - By default, MariaDB only listens on `127.0.0.1` (localhost)
  - Without this, WordPress would get "Connection refused"
- `skip-name-resolve` — don't do DNS reverse lookups on client connections
  - **Performance**: DNS lookups slow down each connection
  - **Container compatibility**: Container hostnames aren't in DNS anyway

### Startup Script: init-mariadb.sh

**File**: `srcs/requirements/mariadb/tools/init-mariadb.sh`

This script solves a fundamental problem: **MariaDB needs to initialize, but containers start fresh every time**.

#### The Problem

When a Docker container starts:
1. The filesystem is the image (read-only) + any volumes (writable)
2. MariaDB needs to create the `mysql` system database (users, permissions, etc.)
3. This initialization should only happen **once** (on first start)
4. On subsequent starts, the database files are already in the volume

#### The Script Flow

```
START
  │
  ├─► Validate required env vars (MYSQL_DATABASE, MYSQL_USER, MYSQL_PASSWORD, MYSQL_ROOT_PASSWORD)
  │
  ├─► Ensure /run/mysqld exists (socket directory)
  │
  ├─► Check if /var/lib/mysql/mysql directory exists
  │     │
  │     ├─► NO (first start) ──► Run initialization:
  │     │    1. mariadb-install-db (create system tables)
  │     │    2. Start mysqld temporarily (with --skip-networking, socket only)
  │     │    3. Wait for it to be ready
  │     │    4. Run SQL to:
  │     │       - Set root password
  │     │       - Create the WordPress database
  │     │       - Create the WordPress user with password
  │     │       - Grant all privileges on the wordpress DB
  │     │    5. Shut down the temporary mysqld
  │     │
  │     └─► YES (existing data) ──► Skip initialization (data already exists)
  │
  └─► exec mysqld --user=mysql --console
       (Take over PID 1, run in foreground)
```

#### Key Detail: The Temporary Server

```bash
mysqld --user=mysql --datadir=/var/lib/mysql --skip-networking --socket=/run/mysqld/mysqld.sock &
temp_pid="$!"

until mariadb-admin --socket=/run/mysqld/mysqld.sock ping >/dev/null 2>&1; do
    sleep 1
done
```

Why start a **temporary** MySQL server just to run SQL, then shut it down?

- MariaDB can only execute SQL when the server is running
- But we need to configure users/databases **before** the main server starts
- Solution: Start a temporary server with `--skip-networking` (only accessible via Unix socket, NOT over the network — security!)
- Run our SQL commands
- Shut it down cleanly
- Then start the real server with `exec`

#### The exec at the End

```bash
exec mysqld --user=mysql --console
```

- `exec` **replaces** the shell process with `mysqld`
- Before `exec`: PID 1 = shell script, shell script runs `mysqld` as child
- After `exec`: PID 1 = `mysqld` directly
- **Why this matters**: Signals (like SIGTERM from `docker stop`) are sent to PID 1
  - Without `exec`: signal goes to shell → shell may not forward it → container takes 10 seconds to timeout and force-kill
  - With `exec`: signal goes directly to `mysqld` → graceful shutdown in milliseconds

---

## 8. Service B: WordPress + PHP-FPM (The Application)

### Dockerfile

**File**: `srcs/requirements/wordpress/Dockerfile`

```dockerfile
FROM debian:bookworm-slim

RUN apt-get update \
    && apt-get install -y --no-install-recommends \
        php-fpm \
        php-mysql \
        mariadb-client \
        curl \
        ca-certificates \
    && rm -rf /var/lib/apt/lists/*
```

- `php-fpm` — the PHP FastCGI Process Manager (handles PHP requests)
- `php-mysql` — PHP extension for connecting to MySQL/MariaDB
- `mariadb-client` — includes `mariadb-admin` (used to wait for DB in the script)
- `curl` — used to download WP-CLI
- `ca-certificates` — needed for HTTPS downloads (like downloading WordPress)

```dockerfile
RUN curl -fsSL https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar \
    -o /usr/local/bin/wp \
    && chmod +x /usr/local/bin/wp
```

- Downloads **WP-CLI** (WordPress Command Line Interface)
- WP-CLI lets us install WordPress, create users, manage plugins — all from the command line
- This is crucial because we can't use a web browser inside a container

```dockerfile
COPY conf/www.conf /etc/php/8.2/fpm/pool.d/www.conf
COPY tools/setup-wordpress.sh /usr/local/bin/setup-wordpress.sh

RUN chmod +x /usr/local/bin/setup-wordpress.sh \
    && mkdir -p /run/php /var/www/html \
    && chown -R www-data:www-data /run/php /var/www/html
```

- `www-data` is the user that PHP-FPM runs as (standard for web applications)
- We pre-create the directories and set ownership so PHP can write to them

```dockerfile
EXPOSE 9000

ENTRYPOINT ["/usr/local/bin/setup-wordpress.sh"]
```

### Configuration: www.conf

**File**: `srcs/requirements/wordpress/conf/www.conf`

```ini
[www]
user = www-data
group = www-data
listen = 9000
listen.owner = www-data
listen.group = www-data
pm = dynamic
pm.max_children = 5
pm.start_servers = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
clear_env = no
```

- `listen = 9000` — PHP-FPM listens on TCP port 9000 (not a Unix socket)
  - **Important**: NGINX connects to `wordpress:9000` via the network
  - If we used a Unix socket, NGINX would need filesystem access to the socket file
- `pm = dynamic` — PHP-FPM can spawn/stop worker processes as needed
  - `pm.max_children = 5` — at most 5 PHP processes
  - `pm.start_servers = 2` — start with 2 workers
- `clear_env = no` — **Critical**: This passes environment variables to PHP scripts
  - Without this, WordPress wouldn't see `MYSQL_PASSWORD` etc.
  - By default, PHP-FPM clears the environment for security. We need to disable that.

### Startup Script: setup-wordpress.sh

**File**: `srcs/requirements/wordpress/tools/setup-wordpress.sh`

This is the most complex script because WordPress installation involves many steps.

#### Real Scenario

On the very first startup:
1. MariaDB starts first, initializes the database
2. WordPress container starts
3. It needs to:
   - Wait for MariaDB to be ready (it takes a few seconds)
   - Download WordPress core files (if not already downloaded)
   - Create `wp-config.php` (database connection details)
   - Run the WordPress installer (set site title, admin user, etc.)
   - Create a second "author" user
4. On subsequent starts (after `make down` + `make up`), skip steps 3-5
5. Start PHP-FPM

#### Script Flow

```
START
  │
  ├─► Validate ALL required env vars (DOMAIN_NAME, MYSQL_*, WP_*)
  │
  ├─► Validate WP_ADMIN_USER doesn't contain "admin" or "administrator"
  │     (If it does → exit with error — this is a project requirement!)
  │
  ├─► Create necessary directories (/run/php, /var/www/html)
  │
  ├─► WAIT for MariaDB to be ready:
  │     ┌─────────────────────────────────────────────────────────┐
  │     │  mariadb-admin ping -hmariadb -u"${MYSQL_USER}" ...    │
  │     │  If it fails → sleep 2 → try again                     │
  │     └─────────────────────────────────────────────────────────┘
  │     This loop runs indefinitely until the DB responds
  │
  ├─► Check if WordPress is already installed:
  │     Check if /var/www/html/wp-config.php exists
  │     │
  │     ├─► NO (first run) ──► Install WordPress:
  │     │    1. wp core download     (download WordPress files)
  │     │    2. wp config create     (create wp-config.php with DB credentials)
  │     │    3. wp core install      (run the installer — creates DB tables, admin user)
  │     │
  │     └─► YES (re-run) ──► Skip installation (data is in the volume)
  │
  ├─► Check if secondary user exists:
  │     if not → wp user create (role: author)
  │
  ├─► Fix ownership: chown -R www-data:www-data /var/www/html /run/php
  │
  └─► exec php-fpm8.2 -F
       (Take over PID 1, run in foreground)
```

#### The Wait Loop Explained

```bash
until mariadb-admin ping -hmariadb -u"${MYSQL_USER}" -p"${MYSQL_PASSWORD}" --silent >/dev/null 2>&1; do
    sleep 2
done
```

This is a **polling loop**:
- Try to ping MariaDB using the service hostname `mariadb` (resolved by Docker DNS)
- If it succeeds → exit the loop (database is ready)
- If it fails → sleep 2 seconds, try again
- `>dev/null 2>&1` suppresses all output (we don't want to see "connection refused" 50 times)

#### Why We Check wp-config.php

```bash
if [ ! -f /var/www/html/wp-config.php ]; then
    # Install WordPress
fi
```

- `wp-config.php` only exists after WordPress is fully installed
- If the file exists → data is already in the volume → skip installation
- This makes the container **idempotent**: you can start/stop it repeatedly without re-installing

#### The Admin Username Check

```bash
if echo "$WP_ADMIN_USER" | grep -Eiq 'admin|administrator'; then
    echo "Invalid WP_ADMIN_USER: must not contain admin/administrator." >&2
    exit 1
fi
```

- The subject explicitly says: "The administrator's username can't contain admin/Admin or administrator/Administrator"
- `grep -Eiq` = extended regex, case-insensitive, quiet (don't print match)
- If the username matches → exit with error, container fails to start
- This is a **hard stop** — the container won't start until you fix the .env file

---

## 9. Service C: NGINX (The Gatekeeper)

### Dockerfile

**File**: `srcs/requirements/nginx/Dockerfile`

```dockerfile
FROM debian:bookworm-slim

RUN apt-get update \
    && apt-get install -y --no-install-recommends nginx openssl \
    && rm -rf /var/lib/apt/lists/*
```

- `nginx` — the web server
- `openssl` — used to generate the self-signed SSL certificate

```dockerfile
COPY conf/default.conf /etc/nginx/conf.d/default.conf
COPY tools/start-nginx.sh /usr/local/bin/start-nginx.sh

RUN chmod +x /usr/local/bin/start-nginx.sh \
    && mkdir -p /etc/ssl/private /etc/ssl/certs
```

- Pre-creates directories for SSL certificates

```dockerfile
EXPOSE 443

ENTRYPOINT ["/usr/local/bin/start-nginx.sh"]
```

### Configuration: default.conf

**File**: `srcs/requirements/nginx/conf/default.conf`

```nginx
server {
    listen 443 ssl;
    server_name _;
```

- `listen 443 ssl` — listen on port 443 with SSL enabled
- `server_name _` — catch-all (responds to any domain name)

```nginx
    ssl_certificate /etc/ssl/certs/inception.crt;
    ssl_certificate_key /etc/ssl/private/inception.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
```

- Path to the self-signed certificate (generated by the startup script)
- `ssl_protocols TLSv1.2 TLSv1.3` — **only** these versions allowed
  - The subject requires TLSv1.2 or TLSv1.3
  - This disables older, insecure protocols (SSLv2, SSLv3, TLSv1.0, TLSv1.1)

```nginx
    root /var/www/html;
    index index.php index.html;
```

- `root /var/www/html` — the document root (same path as the WordPress volume)
- `index index.php index.html` — try these files when a directory is requested

```nginx
    location / {
        try_files $uri $uri/ /index.php?$args;
    }
```

- **The WordPress routing rule**
- For any URL:
  1. Try the exact path as a file (`$uri`)
  2. Try the path as a directory (`$uri/`)
  3. If neither exists → route to `index.php` with the query string
- This enables WordPress's "pretty permalinks" (URLs like `/about` instead of `/?page_id=2`)

```nginx
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass wordpress:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
```

- **The PHP processing rule**
- When a `.php` file is requested:
  1. Include FastCGI parameters (standard set)
  2. Forward the request to `wordpress:9000` (PHP-FPM on the WordPress container)
  3. `fastcgi_param SCRIPT_FILENAME` tells PHP-FPM which file to execute
- `wordpress:9000` works because of Docker's built-in DNS on the custom network

### Startup Script: start-nginx.sh

**File**: `srcs/requirements/nginx/tools/start-nginx.sh`

**File**: `srcs/requirements/nginx/tools/start-nginx.sh`

```
START
  │
  ├─► Validate DOMAIN_NAME environment variable
  │
  ├─► Check if SSL certificate files exist
  │     │
  │     ├─► NO (first start or rebuilt) ──► Generate self-signed certificate:
  │     │    openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
  │     │      -keyout /etc/ssl/private/inception.key \
  │     │      -out /etc/ssl/certs/inception.crt \
  │     │      -subj "/C=MA/ST=NA/L=NA/O=42/OU=Inception/CN=${DOMAIN_NAME}"
  │     │
  │     └─► YES (restart) ──► Reuse existing certificates
  │
  └─► exec nginx -g "daemon off;"
       (Take over PID 1, run in foreground)
```

#### Self-Signed Certificate Breakdown

```bash
openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
    -keyout /etc/ssl/private/inception.key \
    -out /etc/ssl/certs/inception.crt \
    -subj "/C=MA/ST=NA/L=NA/O=42/OU=Inception/CN=${DOMAIN_NAME}"
```

- `-x509` — generate a self-signed certificate (not a certificate request)
- `-nodes` — **no DES** (no password on the private key — so NGINX can read it without manual input)
- `-newkey rsa:2048` — generate a new 2048-bit RSA key
- `-days 365` — certificate is valid for 1 year
- `-subj "..."` — certificate subject details:
  - `C=MA` — Country: Morocco (your location)
  - `ST=NA` / `L=NA` — State/Locality: N/A
  - `O=42` — Organization: 42
  - `OU=Inception` — Organizational Unit: Inception
  - `CN=${DOMAIN_NAME}` — Common Name: (e.g., `mohkhald.42.fr`)

#### Why Self-Signed?

- We can't get a real SSL certificate from a Certificate Authority for a `.42.fr` domain
- A self-signed certificate provides **encryption** (the 'E' in HTTPS)
- But browsers will show a warning because they don't trust the issuer
- This is expected and acceptable for the project

#### nginx -g "daemon off;"

- `-g "daemon off;"` tells NGINX to **stay in the foreground**
- By default, NGINX backgrounds itself (daemon mode)
- In Docker, if the main process backgrounds itself, the container exits immediately
- `daemon off;` keeps NGINX attached to the terminal → PID 1 → container stays running

---

## 10. How It All Starts Up — A Real Scenario

Let's walk through exactly what happens when you run `make all` for the **very first time**.

### Time: T+0 seconds — Makefile starts

```bash
make all
```

1. Make reads the `up` target
2. Runs: `mkdir -p /home/mohkhald/data/mariadb /home/mohkhald/data/wordpress`
3. Creates empty directories on the host

### Time: T+1 second — Docker Compose starts

```bash
docker compose -f srcs/docker-compose.yml --env-file srcs/.env up -d --build
```

Docker Compose reads the YAML file and begins building.

### Time: T+5 seconds — Image building (parallel)

Docker builds three images simultaneously:

**MariaDB build**:
1. Pulls `debian:bookworm-slim` from Docker Hub
2. Runs `apt-get update && apt-get install mariadb-server`
3. Copies `50-server.cnf` and `init-mariadb.sh`
4. Tags the image as `mariadb`

**WordPress build**:
1. Pulls `debian:bookworm-slim`
2. Installs PHP-FPM, PHP-MySQL, MariaDB client, curl
3. Downloads WP-CLI
4. Copies `www.conf` and `setup-wordpress.sh`
5. Tags the image as `wordpress`

**NGINX build**:
1. Pulls `debian:bookworm-slim`
2. Installs NGINX and OpenSSL
3. Copies `default.conf` and `start-nginx.sh`
4. Tags the image as `nginx`

### Time: T+60 seconds — Containers start

Docker Compose starts containers **in dependency order**:
- First: `mariadb` (no `depends_on`)
- Then: `wordpress` (depends on `mariadb`)
- Finally: `nginx` (depends on `wordpress`)

### Time: T+65 seconds — MariaDB container starts

The container runs `init-mariadb.sh`:

1. Validates env vars (all present ✓)
2. Creates `/run/mysqld`
3. Checks `/var/lib/mysql/mysql` — **it's empty** (first start)
4. Runs `mariadb-install-db` — creates system tables
5. Starts a temporary `mysqld` on a Unix socket (no network)
6. Waits for it to be ready
7. Runs SQL:
   - Sets root password to `MYSQL_ROOT_PASSWORD`
   - Creates database `wordpress`
   - Creates user `wpuser` with password
   - Grants all privileges on `wordpress` database to `wpuser`
8. Shuts down temporary server
9. Runs `exec mysqld --user=mysql --console`
10. MariaDB is now running and listening on port 3306

### Time: T+75 seconds — WordPress container starts

The container runs `setup-wordpress.sh`:

1. Validates all env vars ✓
2. Checks admin username — `siteowner42` doesn't contain "admin" ✓
3. Creates `/run/php` and `/var/www/html`
4. **Enters wait loop**: `mariadb-admin ping -hmariadb...`
   - Tries to ping MariaDB
   - MariaDB is still starting up → fails → sleep 2 → retry
   - After a few seconds, MariaDB accepts the connection → loop exits
5. Checks for `wp-config.php` — **doesn't exist** (first start)
6. Downloads WordPress core: `wp core download`
7. Creates `wp-config.php` with database connection details
8. Runs WordPress installer: `wp core install`
   - Creates all WordPress database tables (wp_posts, wp_users, etc.)
   - Creates admin user `siteowner42` with password
   - Sets site URL to `https://mohkhald.42.fr`
9. Creates secondary user `learner42` with role `author`
10. Fixes file ownership: `chown -R www-data:www-data`
11. Runs `exec php-fpm8.2 -F`
12. PHP-FPM is now listening on port 9000

### Time: T+130 seconds — NGINX container starts

The container runs `start-nginx.sh`:

1. Validates `DOMAIN_NAME` ✓
2. Checks for SSL cert files — **they don't exist** (first start)
3. Generates self-signed certificate for `mohkhald.42.fr`
4. Runs `exec nginx -g "daemon off;"`
5. NGINX is now listening on port 443

### Time: T+135 seconds — Stack is fully operational

```bash
$ make ps
CONTAINER ID   IMAGE      COMMAND                  STATUS
abc123         mariadb    "/usr/local/bin/ini..."   Up 2 minutes
def456         wordpress  "/usr/local/bin/set..."  Up 1 minute
ghi789         nginx      "/usr/local/bin/sta..."  Up 30 seconds
```

```bash
$ curl -k https://mohkhald.42.fr
<!DOCTYPE html>
<html>
<head>...
<title>Inception</title>
...
```

**WordPress is live!** 🎉

### What Happens on Second Start (make down + make up)

1. No need to rebuild unless code changed
2. MariaDB starts → finds existing `/var/lib/mysql/mysql` → skips init → starts directly
3. WordPress starts → finds existing `wp-config.php` → skips install → starts PHP-FPM
4. NGINX starts → finds SSL certs from previous run → starts directly
5. **All data is preserved** in the volumes

---

## 11. What Happens When Something Crashes

### Scenario: WordPress container crashes (out of memory, PHP bug)

1. Docker detects the container has stopped (status: exited)
2. Because `restart: always` is set, Docker automatically restarts it
3. The startup script runs again:
   - Finds `wp-config.php` exists → skip installation
   - Fixes permissions
   - Starts PHP-FPM
4. NGINX notices the backend (wordpress:9000) was briefly down
   - NGINX queues or rejects requests during the downtime
   - Once WordPress is back, NGINX resumes proxying
5. Total downtime: 5-30 seconds

### Scenario: Host machine reboots

1. Docker daemon starts at boot (if enabled with `systemctl enable docker`)
2. Docker Compose is NOT automatically restarted (we'd need `--restart always` on compose)
3. **You run**: `make all` (or `make up`)
4. Docker starts all containers
5. Data is intact in `/home/mohkhald/data/`
6. The stack is back online

### Scenario: Volume gets corrupted

1. MariaDB fails to start (can't read database files)
2. **Solution**: Delete the volume data and rebuild:
   ```bash
   make fclean
   make all
   ```
3. WordPress gets a fresh installation (no previous data)

---

## 12. Critical Rules Explained (Why the Subject Forbids X)

### ❌ Rule 1: No `latest` tag

**The rule**: Every `FROM` must specify a version, not `:latest`.

**Why**: `latest` changes over time. If you build today, it's Debian 12. If you build in 6 months, it might be Debian 13. Your project might break. A specific version like `bookworm-slim` is predictable and stable.

### ❌ Rule 2: No passwords in Dockerfiles

**The rule**: Dockerfiles must not contain `MYSQL_ROOT_PASSWORD=secret`.

**Why**: Dockerfiles are often committed to Git. If a password is in a Dockerfile, it's visible to anyone who can read your repo. Environment variables from `.env` (which is in `.gitignore`) keep secrets out of the codebase.

### ❌ Rule 3: No `tail -f`, `sleep infinity`, `while true`

**The rule**: Don't use hacky methods to keep containers alive.

**Why**: These are **anti-patterns**. They show you don't understand how Docker works.
- A container runs only as long as its main process runs
- The correct approach: run your service in the **foreground** as PID 1
- `tail -f /dev/null` keeps a container alive but does nothing useful
- In our project, `mysqld`, `php-fpm -F`, and `nginx -g "daemon off;"` all run in the foreground → container stays alive naturally

### ❌ Rule 4: No `network: host`

**The rule**: Each container must have its own network namespace.

**Why**: `network: host` makes the container share the host's network stack. This:
- Bypasses Docker's network isolation
- Exposes all container ports directly on the host
- Prevents container-to-container DNS resolution by name
- Our custom `inception` network gives us isolation + service discovery

### ❌ Rule 5: No bind mounts for the two main volumes

**The rule**: Use named volumes, not bind mounts.

**Why**: The subject tests whether you understand the difference (one of the 4 required README comparisons). Our "named volume with bind mount driver option" is the correct workaround — it's technically a named volume but stores data at the required host path.

### ❌ Rule 6: No "admin" in the admin username

**The rule**: The WordPress admin username can't contain "admin" or "administrator".

**Why**: Brute force attacks target the "admin" username because it's the default. By forcing a unique username, you reduce the risk of automated attacks.

### ❌ Rule 7: NGINX must be the only entrypoint on port 443

**The rule**: Only port 443 is exposed. TLS 1.2/1.3 only.

**Why**: This is a **defense in depth** strategy:
- No plain HTTP (port 80) — all traffic must be encrypted
- Only NGINX is exposed — attackers can't reach WordPress or MariaDB directly
- Old TLS versions are disabled (they have known vulnerabilities)

---

## 13. What You Need to Do Next

### Phase 1: Set Up Your VM

On your school VM (or local VirtualBox VM):

```bash
# 1. Fix sudo if needed
su -
apt update
apt install -y sudo
usermod -aG sudo $USER
exit
# Logout and login again

# 2. Install required tools
sudo apt update
sudo apt install -y openssh-server docker.io docker-compose make

# 3. Start services
sudo systemctl enable --now ssh docker

# 4. Allow docker without sudo
sudo usermod -aG docker $USER
# Logout and login again

# 5. Verify docker works
docker ps
docker --version
```

**If apt update fails with "Not live until" errors** → your VM clock is wrong:

```bash
sudo date -s "2026-07-14 12:00:00"   # Set to current date/time
sudo hwclock --systohc
sudo apt clean && sudo apt update
```

### Phase 2: Get the Project Files on the VM

Options:
- **SSH + git**: If your repo is on GitHub
  ```bash
  git clone <repo-url> ~/inception
  ```
- **SCP from host** (if files are on your host machine):
  ```bash
  # From host:
  scp -r /path/to/inception <user>@<vm-ip>:~/inception
  ```

### Phase 3: Configure .env

```bash
cd ~/inception
cp srcs/.env.example srcs/.env
nano srcs/.env
```

Change these:
- `LOGIN=mohkhald` → your actual system username
- `DOMAIN_NAME=mohkhald.42.fr` → your login.42.fr
- All passwords → strong, unique passwords

### Phase 4: Configure Domain Resolution

```bash
echo "127.0.0.1 mohkhald.42.fr" | sudo tee -a /etc/hosts
```

This maps the domain to localhost so the browser can find the site.

### Phase 5: Build and Run

```bash
cd ~/inception
make all
```

First run takes 3-5 minutes (downloading packages, installing WordPress).

### Phase 6: Verify

```bash
# Check all containers are running
make ps

# Test within the VM
curl -k https://mohkhald.42.fr

# Stream logs (Ctrl+C to exit)
make logs
```

### Phase 7: Access from Host

On your **host machine** (the computer running VirtualBox):

```bash
# Add the domain mapping
echo "<vm-ip> mohkhald.42.fr" | sudo tee -a /etc/hosts
```

Then open `https://mohkhald.42.fr` in your browser.

### Phase 8: WordPress Admin

1. Go to `https://mohkhald.42.fr/wp-admin`
2. Log in with `WP_ADMIN_USER` / `WP_ADMIN_PASSWORD` from `.env`

---

## 14. Common Pitfalls & How to Debug

### Pitfall 1: Volume Path Mismatch

**Symptom**: MariaDB or WordPress data isn't persisting, or containers can't write to volumes.

**Cause**: The `LOGIN` in `.env` doesn't match your actual Linux username.

**Fix**:
```bash
# Check your username
whoami

# Compare with .env
cat srcs/.env | grep LOGIN=

# They must match!
```

### Pitfall 2: Port 443 Already in Use

**Symptom**: NGINX container crashes immediately.

**Fix**:
```bash
# Find what's using port 443
sudo lsof -i :443

# It's probably another web server. Stop it:
sudo systemctl stop apache2   # or nginx
```

### Pitfall 3: Docker Permission Denied

**Symptom**:
```
docker: permission denied while trying to connect to the Docker daemon socket
```

**Cause**: Your user isn't in the `docker` group, or you haven't logged out since being added.

**Fix**:
```bash
sudo usermod -aG docker $USER
# Then logout and login again
# Or use: newgrp docker
```

### Pitfall 4: WordPress Can't Connect to Database

**Symptom**: WordPress shows "Error establishing a database connection"

**Fix**:
```bash
# Check if MariaDB is running
make ps

# Check MariaDB logs
docker logs mariadb

# Check if credentials match .env
docker exec -it mariadb mariadb -u wpuser -p
# Enter MYSQL_PASSWORD from .env
# If this fails, credentials don't match

# Full reset
make fclean && make all
```

### Pitfall 5: DNS Resolution Inside Containers

**Symptom**: WordPress can't resolve hostname `mariadb`.

**Fix**: The containers must all be on the same Docker network.

```bash
# Check which network(s) each container is on
docker inspect mariadb | grep -A 10 Networks
docker inspect wordpress | grep -A 10 Networks

# They should all be on "inception"
# If not, check docker-compose.yml for the networks: section
```

### Pitfall 6: Browser Shows "Your Connection Is Not Private"

**Cause**: Self-signed certificate. This is expected.

**Fix**: Click "Advanced" → "Proceed to site". Or import the certificate to your trust store.

### Pitfall 7: SSH from Host to VM Not Working

**Fix**:
```bash
# On VM, verify SSH is running
sudo systemctl status ssh

# Check VM IP
ip -4 a

# VirtualBox network must be "Bridged Adapter" (not NAT)
# In VirtualBox: VM Settings → Network → Adapter 1 → Bridged
```

### Checking Logs (Your Best Debugging Tool)

```bash
# All services
make logs

# Specific service
docker logs mariadb
docker logs wordpress
docker logs nginx

# Follow a specific service
docker logs -f mariadb
```

### The Nuclear Reset (When Nothing Else Works)

```bash
make fclean && make all
```
This **completely resets everything**: containers, images, volumes, and data. You get a fresh start.

---

## Quick Reference: Key Files Cheat Sheet

| File | Purpose | Key Details |
|------|---------|-------------|
| `Makefile` | Control center | `all`, `down`, `clean`, `fclean`, `re`, `logs`, `ps` |
| `docker-compose.yml` | Infrastructure blueprint | 3 services, 1 network, 2 volumes, restart policies |
| `.env` | Secrets & config | Keep out of Git! Maps to `${VAR}` references |
| `mariadb/Dockerfile` | DB image build | Debian + MariaDB-server |
| `mariadb/tools/init-mariadb.sh` | DB startup | First-run init, then `exec mysqld` |
| `mariadb/conf/50-server.cnf` | DB config | Bind to 0.0.0.0, port 3306 |
| `wordpress/Dockerfile` | App image build | Debian + PHP-FPM + WP-CLI |
| `wordpress/tools/setup-wordpress.sh` | App startup | Wait for DB, install WP, create users, `exec php-fpm` |
| `wordpress/conf/www.conf` | PHP-FPM config | Listen 9000, `clear_env = no` |
| `nginx/Dockerfile` | Gateway image build | Debian + NGINX + OpenSSL |
| `nginx/tools/start-nginx.sh` | Gateway startup | Generate SSL cert, `exec nginx` |
| `nginx/conf/default.conf` | NGINX config | TLS 1.2/1.3, proxy to wordpress:9000 |

---

## Final Words

This project teaches you the **real-world workflow** of modern cloud applications:

1. **Infrastructure as Code**: Everything is defined in files (Dockerfiles, compose, configs)
2. **Immutable Infrastructure**: You never SSH into a container to fix things — you rebuild it
3. **Separation of Concerns**: Database, application, and web server are independent
4. **Security by Default**: TLS only, minimal port exposure, least privilege principle
5. **Resilience**: Auto-restart, persistent volumes, health checks

## check server connection with **nc -vz <domainName> <port>** cli
