#!/bin/sh
set -eu

required_var() {
	name="$1"
	eval "value=\${$name:-}"
	if [ -z "$value" ]; then
		echo "Missing required environment variable: $name" >&2
		exit 1
	fi
}

required_var DOMAIN_NAME
required_var MYSQL_DATABASE
required_var MYSQL_USER
required_var MYSQL_PASSWORD
required_var WP_TITLE
required_var WP_ADMIN_USER
required_var WP_ADMIN_PASSWORD
required_var WP_ADMIN_EMAIL
required_var WP_USER
required_var WP_USER_PASSWORD
required_var WP_USER_EMAIL

if echo "$WP_ADMIN_USER" | grep -Eiq 'admin|administrator'; then
	echo "Invalid WP_ADMIN_USER: must not contain admin/administrator." >&2
	exit 1
fi

mkdir -p /run/php /var/www/html

until mariadb-admin ping -hmariadb -u"${MYSQL_USER}" -p"${MYSQL_PASSWORD}" --silent >/dev/null 2>&1; do
	sleep 2
done

if [ ! -f /var/www/html/wp-config.php ]; then
	wp core download --path=/var/www/html --allow-root

	wp config create \
		--path=/var/www/html \
		--dbname="${MYSQL_DATABASE}" \
		--dbuser="${MYSQL_USER}" \
		--dbpass="${MYSQL_PASSWORD}" \
		--dbhost="mariadb:3306" \
		--allow-root \
		--skip-check

	wp core install \
		--path=/var/www/html \
		--url="https://${DOMAIN_NAME}" \
		--title="${WP_TITLE}" \
		--admin_user="${WP_ADMIN_USER}" \
		--admin_password="${WP_ADMIN_PASSWORD}" \
		--admin_email="${WP_ADMIN_EMAIL}" \
		--skip-email \
		--allow-root
fi

if ! wp user get "${WP_USER}" --path=/var/www/html --allow-root >/dev/null 2>&1; then
	wp user create "${WP_USER}" "${WP_USER_EMAIL}" \
		--path=/var/www/html \
		--user_pass="${WP_USER_PASSWORD}" \
		--role=author \
		--allow-root
fi

chown -R www-data:www-data /var/www/html /run/php

exec php-fpm8.2 -F

