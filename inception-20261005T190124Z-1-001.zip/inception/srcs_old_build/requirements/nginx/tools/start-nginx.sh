#!/bin/sh
set -eu

if [ -z "${DOMAIN_NAME:-}" ]; then
	echo "Missing required environment variable: DOMAIN_NAME" >&2
	exit 1
fi

if [ ! -s /etc/ssl/private/inception.key ] || [ ! -s /etc/ssl/certs/inception.crt ]; then
	openssl req -x509 -nodes -newkey rsa:2048 -days 365 \
		-keyout /etc/ssl/private/inception.key \
		-out /etc/ssl/certs/inception.crt \
		-subj "/C=MA/ST=NA/L=NA/O=42/OU=Inception/CN=${DOMAIN_NAME}"
fi

exec nginx -g "daemon off;"
