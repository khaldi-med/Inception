# Inception

### Docker definition:
* Docker lets you package an application + its dependencies into an image, then run it in an isolated container on the host — sharing the host's kernel, but with its own filesystem, processes, and network.

* A container shares the host's kernel (Linux kernel). It doesn't boot its own OS. That's what makes it "lightweight" vs a virtual machine. A VM runs a full OS (kernel + userspace), a container is just the userspace (binaries, libs, config) on top of the host kernel.

* 
