# IMPLEMENTATION_SUMMARY.md

## ✅ Inception Project – Complete Scaffold

This document summarizes what has been built and what remains to be done on your VM.

---

## What's Been Created (In Repository)

### 📋 Documentation
- ✅ `README.md` – Full project overview with mandatory italicized intro + 4 required comparisons (VM vs Docker, Secrets vs Env, Network modes, Volume types)
- ✅ `USER_DOC.md` – End-user guide (start, stop, access, credentials, troubleshooting)
- ✅ `DEV_DOC.md` – Developer guide (setup, modification, debugging)
- ✅ `SCHOOL_VM_SETUP.md` – VM bootstrap guide (reusable for school machines)

### 🛠️ Makefile & Build
- ✅ `Makefile` – Targets: `all`, `up`, `down`, `clean`, `fclean`, `re`, `logs`, `ps`
- ✅ `.gitignore` – Excludes `secrets/`, `srcs/.env`

### 🐳 Docker Compose
- ✅ `srcs/docker-compose.yml` – Defines 3 services + custom network + 2 named volumes (bound to `/home/$LOGIN/data/`)
- ✅ `srcs/.env.example` – Template with all required variables

### 🐘 MariaDB Service
- ✅ `srcs/requirements/mariadb/Dockerfile` – Debian slim, installs MariaDB
- ✅ `srcs/requirements/mariadb/conf/50-server.cnf` – Config: bind to 0.0.0.0, skip-name-resolve
- ✅ `srcs/requirements/mariadb/tools/init-mariadb.sh` – Init script: validates env vars, creates DB + users, runs `mysqld --console`
- ✅ `srcs/requirements/mariadb/.dockerignore` – Excludes unnecessary files

### 🔵 WordPress + PHP-FPM Service
- ✅ `srcs/requirements/wordpress/Dockerfile` – Debian slim, PHP-FPM + extensions, WP-CLI
- ✅ `srcs/requirements/wordpress/conf/www.conf` – PHP-FPM pool: listens on 9000, dynamic process manager
- ✅ `srcs/requirements/wordpress/tools/setup-wordpress.sh` – Setup: validates env vars, waits for DB, downloads WP, auto-installs, creates 2 users, runs `php-fpm -F`
- ✅ `srcs/requirements/wordpress/.dockerignore` – Excludes unnecessary files

### 🌐 NGINX Service
- ✅ `srcs/requirements/nginx/Dockerfile` – Debian slim, NGINX + OpenSSL
- ✅ `srcs/requirements/nginx/conf/default.conf` – TLS config: port 443, TLSv1.2/1.3, reverse proxy to wordpress:9000 (FastCGI)
- ✅ `srcs/requirements/nginx/tools/start-nginx.sh` – Startup: generates self-signed cert, runs `nginx -g "daemon off;"`
- ✅ `srcs/requirements/nginx/.dockerignore` – Excludes unnecessary files

---

## What You Need to Do (On Your VM)

### Phase 1: VM Setup (5 minutes)
```bash
# SSH into VM
ssh $USER@<vm_ip>

# (If not yet done) Fix admin rights, install tools
su -
apt update
apt install -y sudo openssh-server docker.io docker-compose make
usermod -aG sudo $USER
exit
sudo systemctl enable --now ssh docker
sudo usermod -aG docker $USER
# Logout/login once
```

### Phase 2: Clone Repository & Configure (2 minutes)
```bash
cd ~
git clone <repo-url> inception  # or copy files
cd inception
cp srcs/.env.example srcs/.env

# Edit srcs/.env with YOUR login and passwords
nano srcs/.env
```

**Critical**: Replace these with your actual values:
```env
LOGIN=yourusername                    # e.g., mohkhald
DOMAIN_NAME=yourusername.42.fr        # e.g., mohkhald.42.fr
MYSQL_PASSWORD=<strong_password>      # Min 12 chars
MYSQL_ROOT_PASSWORD=<strong_password>
WP_ADMIN_USER=<not_admin_word>        # e.g., siteowner42 (NOT admin!)
WP_ADMIN_PASSWORD=<strong_password>
WP_USER_PASSWORD=<strong_password>
```

### Phase 3: Build & Deploy (3-5 minutes on first run)
```bash
cd ~/inception
make all
```

**Expected output**:
- Images built ✓
- Containers started ✓
- Initial logs show MariaDB init, WordPress install, NGINX startup

**Wait 2-3 minutes** for WordPress to fully initialize.

### Phase 4: Verify
```bash
make ps          # Should show 3 running containers
curl -k https://yourusername.42.fr    # Inside VM
make logs        # Stream container logs
```

### Phase 5: Access
From **host machine**:
```bash
# Edit /etc/hosts (or equivalent)
echo "127.0.0.1 yourusername.42.fr" | sudo tee -a /etc/hosts
# Then in browser:
https://yourusername.42.fr
```

Accept self-signed certificate warning. You should see WordPress homepage or setup screen.

---

## Compliance Checklist

### ✅ Mandatory Requirements (42 Rubric)

- [x] **Own Dockerfiles** – All 3 services use custom Dockerfiles (no prebuilt image pulls)
- [x] **No `latest` tag** – All FROM statements use specific versions (bookworm-slim)
- [x] **3 Services** – nginx, wordpress (php-fpm), mariadb each in separate containers
- [x] **Named Volumes** – 2 volumes (mariadb_data, wordpress_data) with bind mounts to `/home/$LOGIN/data/`
- [x] **Custom Network** – Docker network named `inception`
- [x] **NGINX Only on 443** – Only port 443 exposed, TLS 1.2/1.3 only
- [x] **No Passwords in Code** – All from `.env` (environment variables)
- [x] **No `tail -f` / Loops** – All services use `exec` to foreground main process (mysqld, php-fpm, nginx)
- [x] **No `network: host`** – Uses custom bridge network
- [x] **Restart Policy** – All services have `restart: always`
- [x] **2 WordPress Users** – Admin + secondary user created by setup script
- [x] **No "admin" in Admin Username** – Validated in setup script
- [x] **Domain Name** – Configured as `<login>.42.fr`
- [x] **README.md** – Includes mandatory italicized intro + 4 comparisons
- [x] **USER_DOC.md** – Instructions for start, stop, access, credentials
- [x] **DEV_DOC.md** – Technical reproduction guide + modification examples

---

## Architecture Diagram

```
┌─ Host Machine ──────────────────────────────────────────┐
│                                                         │
│  /home/$USER/data/                                      │
│  ├── mariadb/          ◄── Named volume bind mount       │
│  └── wordpress/        ◄── Named volume bind mount       │
│                                                         │
│  ┌─ Docker Network: inception ──────────────────────┐  │
│  │                                                  │  │
│  │  ┌──────────────┐  ┌────────────────┐           │  │
│  │  │ NGINX        │  │ WordPress+    │           │  │
│  │  │ Port 443     │─►│ PHP-FPM       │           │  │
│  │  │ TLS 1.2/1.3  │  │ Port 9000     │           │  │
│  │  │              │  │ FastCGI       │           │  │
│  │  └──────────────┘  └────────────────┘           │  │
│  │       ▲                    │                     │  │
│  │       │                    ▼                     │  │
│  │  HTTPS requests       ┌──────────────┐           │  │
│  │  (from host/browser)  │ MariaDB      │           │  │
│  │                       │ Port 3306    │           │  │
│  │                       │              │           │  │
│  │                       └──────────────┘           │  │
│  │                                                  │  │
│  └──────────────────────────────────────────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Next Steps (Bonus Features)

Once mandatory part passes:

### Bonus Ideas (Choose 1+ for extra points)
1. **Redis Cache** – Add caching layer for WordPress
2. **FTP Server** – Manage WordPress files via FTP
3. **Static Website** – Add a simple HTML/CSS/JS site (non-PHP)
4. **Adminer** – Web-based database administration tool
5. **Custom Service** – Something useful (e.g., Backup service, Monitoring)

Each bonus requires a new Dockerfile + service in compose.

---

## Troubleshooting Quick Ref

| Issue | Fix |
|-------|-----|
| Port 443 in use | `sudo lsof -i :443` and kill process |
| Docker permission denied | `sudo usermod -aG docker $USER` + logout/login |
| MariaDB won't init | `make fclean && make all` (full reset) |
| WordPress stuck loading | `make logs` (check database connection) |
| Can't access site from host | Ensure VM bridged network, add to `/etc/hosts` |
| SSL certificate warnings | Expected (self-signed). Proceed in browser. |

---

## Files & Their Purposes

| File | Purpose |
|------|---------|
| `Makefile` | Orchestrates all Docker commands |
| `docker-compose.yml` | Defines services, volumes, network |
| `.env` | Runtime configuration (credentials, domain) |
| `Dockerfile` (×3) | Build images for each service |
| `init-mariadb.sh` | Database initialization & startup |
| `setup-wordpress.sh` | WordPress download, install, user creation |
| `start-nginx.sh` | SSL cert generation & NGINX startup |
| `*.conf` / `*.cnf` | Service-specific configuration |
| `README.md` | Project overview (for evaluators) |
| `USER_DOC.md` | End-user guide |
| `DEV_DOC.md` | Developer guide |

---

## Ready to Deploy?

1. Copy files to school VM (SSH or USB)
2. Follow **Phase 1–5** above
3. Run `make all`
4. Test: `curl -k https://yourlogin.42.fr`
5. Commit to Git (excluding `.env` and `secrets/`)
6. Submit for peer evaluation

Good luck! 🚀
