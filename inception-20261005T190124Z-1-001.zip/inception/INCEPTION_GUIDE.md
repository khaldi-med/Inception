# 🚀 Inception Project Build Guide

Welcome, peer learner! This guide breaks down the "Inception" project into manageable phases. We are building a virtualized infrastructure using Docker, focusing on system administration and security.

## 📌 Project Overview
The goal is to set up a WordPress site powered by MariaDB and served by NGINX, all running in separate Docker containers on a Virtual Machine.

---

## 🛠️ Phase 1: Environment & Foundation
Before touching Docker, you need your playground ready.

1.  **Virtual Machine:** Ensure you are working inside a VM (as required).
2.  **Tools Installation:**
    *   Install **Docker**.
    *   Install **Docker Compose**.
3.  **Project Structure:** Create the directory layout exactly as specified:
    ```text
    .
    ├── Makefile
    ├── secrets/             # (Add to .gitignore!)
    └── srcs/
        ├── .env
        ├── docker-compose.yml
        └── requirements/
            ├── mariadb/
            │   ├── Dockerfile
            │   └── conf/
            ├── nginx/
            │   ├── Dockerfile
            │   └── conf/
            └── wordpress/
                ├── Dockerfile
                └── conf/
    ```
4.  **Domain Configuration:** Add your domain to `/etc/hosts` on the host VM:
    `127.0.0.1  yourlogin.42.fr`

---

## 🏗️ Phase 2: The Database (MariaDB)
Start with the data layer.

1.  **Base Image:** Use Debian or Alpine (penultimate stable version). **No `latest` tag.**
2.  **Dockerfile:** 
    *   Install MariaDB server.
    *   Configure it to listen on all interfaces.
    *   Create a script to initialize the DB, create the two users (admin and another), and set passwords using environment variables.
3.  **Storage:** Use a **named volume** that maps to `/home/login/data/mariadb`.
4.  **Execution:** Ensure the process runs in the foreground (avoid `tail -f` or `sleep infinity`).

---

## 📝 Phase 3: The Application (WordPress + php-fpm)
Now, the logic layer.

1.  **Base Image:** Same OS as MariaDB.
2.  **Dockerfile:**
    *   Install PHP-FPM and the necessary PHP extensions for WordPress (e.g., `php-mysql`).
    *   Download and install WordPress.
    *   Configure `wp-config.php` to use environment variables for DB connection.
3.  **Storage:** Use a **named volume** that maps to `/home/login/data/wordpress`.
4.  **Execution:** Run `php-fpm` in the foreground.

---

## 🌐 Phase 4: The Gateway (NGINX)
The only entry point to your system.

1.  **Base Image:** Same OS as the others.
2.  **Dockerfile:**
    *   Install NGINX.
    *   Generate a **self-signed SSL certificate**.
    *   Configure NGINX to use **TLSv1.2 or TLSv1.3 only**.
    *   Set up a reverse proxy to forward requests to the WordPress container via port 9000 (FastCGI).
3.  **Networking:** Expose only port **443**.

---

## 🔗 Phase 5: Orchestration & Integration
Tying it all together.

1.  **`.env` File:** Store all secrets (DB passwords, usernames, domain) here.
2.  **`docker-compose.yml`:**
    *   Define the three services (`mariadb`, `wordpress`, `nginx`).
    *   Define a custom **docker-network**.
    *   Set the `restart: always` policy.
    *   Map the named volumes to the specific host paths.
3.  **Makefile:** Create a Makefile to:
    *   `all`: Run `docker-compose up --build -d`.
    *   `down`: Stop and remove containers.
    *   `clean`: Remove images and volumes.

---

## 📚 Phase 6: Documentation & Validation
The project isn't finished until it's documented.

1.  **`README.md`:** Include the mandatory italicized header, project description, and the 4 required comparisons (VM vs Docker, etc.).
2.  **`USER_DOC.md`:** Instructions for an end-user to start the site and manage credentials.
3.  **`DEV_DOC.md`:** Technical guide for another developer to reproduce the setup.

---

## ⚠️ Critical Rules (Don't Fail!)
*   ❌ **No `latest` tags** in Dockerfiles.
*   ❌ **No passwords** written directly in Dockerfiles.
*   ❌ **No `tail -f`, `sleep infinity`, or `while true`** in entrypoints.
*   ❌ **No bind mounts** for the two main volumes (use named volumes).
*   ❌ **No `network: host`** or `--link`.
*   ❌ **No "admin"** in the WordPress administrator's username.
