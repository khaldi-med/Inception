# Copilot instructions for the Inception repo

Purpose: help Copilot sessions start quickly and act usefully in this repository.

---
1) Build, run, test, and debug commands

- Primary (full stack):
  - make all   # builds images, creates volume host dirs, and starts everything detached
  - make down  # stop containers (keep host data)
  - make clean # remove containers, local images, compose-managed volumes
  - make fclean # removes containers/images and wipes host bind dirs (requires sudo)
  - make re    # fclean then all

- Per-service / targeted operations:
  - Rebuild & restart one service:
    docker compose -f srcs/docker-compose.yml --env-file srcs/.env up -d --build <service>
    (e.g. ... up -d --build nginx)
  - Stream logs for a single service:
    docker compose -f srcs/docker-compose.yml --env-file srcs/.env logs -f nginx
  - Run an interactive shell in a container:
    docker exec -it <container_name> /bin/bash
  - Check NGINX config inside container:
    docker exec -it nginx nginx -t
  - Verify HTTPS endpoint (local VM):
    curl -k https://localhost
  - Quick DB check (inside mariadb):
    docker exec -it mariadb mariadb -u root -p -e "SELECT 1;"

- Notes about tests & lint:
  - No automated unit tests or linters are present in the repo. Use the per-service checks above (nginx -t, WP-CLI commands, DB query) as single-step verifications.

---
2) High-level architecture (quick reference)

- Three services on custom bridge network `inception`:
  - mariadb (data layer) — binds /var/lib/mysql to named volume mariadb_data (host: /home/${LOGIN}/data/mariadb)
  - wordpress (app layer + php-fpm) — serves PHP via TCP on port 9000 inside network
  - nginx (edge) — terminates TLS, reverse-proxies to wordpress:9000, only host port exposed: 443
- Volumes: named volumes are driver-mounted to host paths under /home/<LOGIN>/data/ (subject requirement).
- Entrypoints: custom scripts initialize/bootstrap then `exec` the daemon so the main process is PID 1 (no tail/sleep hacks).

Files to read first when starting a session: AGENTS.md, README.md, Makefile, srcs/docker-compose.yml, srcs/.env.example, subject.md

---
3) Key repository conventions and rules (must-follow)

- Dockerfiles: use explicit tags (debian:bookworm-slim). Never use `:latest`.
- Secrets: runtime from srcs/.env (gitignored). Never hardcode credentials in Dockerfiles.
- Volumes: use named volumes with driver_opts binding to /home/<LOGIN>/data/ (the compose files follow this pattern). Host paths must exist before `make all`.
- Admin user policy: WP_ADMIN_USER must NOT contain "admin" or "administrator".
- Networking: do not use host networking or links — services discover each other by name on the `inception` network.
- PID 1: entrypoint scripts must `exec` the real daemon (mysqld, php-fpm, nginx) to ensure proper signal handling.
- Makefile: uses `srcs/.env` and auto-detects `docker compose` vs `docker-compose`. Prefer `make` targets for reproducible evaluator runs.

---
4) Guidance for Copilot sessions (how to behave)

- Teaching mode: when asked to teach or explain, follow AGENTS.md (Socratic, one-question-at-a-time, reference real files). Always read AGENTS.md before starting a lesson.
- When asked to modify or patch code:
  - Create a branch locally, make small surgical edits, run `make up` or per-service rebuild to verify, then open a PR. Use /diff, /delegate, /pr to operate on commits and PRs.
- For multi-step changes, produce a /plan first, then map steps to /tasks so progress is persisted and resumable.
- If the user requests exports or sharing, use `/share markdown|gist` to produce a portable record of the session.

---
5) Quick troubleshooting checklist (one-liners to try first)

- "make ps" — are containers running?
- "docker compose -f srcs/docker-compose.yml --env-file srcs/.env logs -f <service>" — check service logs
- "docker exec -it nginx nginx -T" — inspect effective nginx config
- "docker network inspect inception" — verify network membership
- "sudo chown -R $USER:$USER /home/$USER/data/wordpress" — fix WP file permissions if uploads fail

---
6) Files & areas Copilot should consult before making changes

- AGENTS.md (teaching & behavior rules)
- Makefile, srcs/docker-compose.yml, srcs/.env.example
- srcs/requirements/*/{Dockerfile,conf,tools/*} (entrypoint scripts & runtime behavior)
- subject.md and INCEPTION_GUIDE.md for evaluation constraints and grading rules

---
7) When no tests are present: how to present verification steps

- If proposing code changes, include explicit manual verification steps the assistant will run (rebuild one image, run nginx -t, curl -k, WP-CLI checks, DB query).
- Add small smoke checks to PRs (e.g., `docker compose up -d --build nginx && docker exec nginx nginx -t`) so reviewers can reproduce.

---
8) Integrations & other assistant configs

- AGENTS.md exists and must be followed for teaching interactions. GEMINI.md is present but empty; no additional CLAUDE.md found.

---
Created: a focused Copilot instructions file to accelerate agent sessions in this repository.

If you want, add MCP server support (Playwright or other web testing) now — do you want help configuring an MCP server for automated end-to-end checks?
