# Inception VM Setup (School Machine)

This guide is a practical checklist to prepare a fresh VM for the 42 **Inception** project.

---

## 1) First login and root/admin recovery

If your user cannot run `sudo` (`is not in the sudoers file`), fix it first:

```bash
su -
apt update
apt install -y sudo
usermod -aG sudo <your_user>
exit
```

Then logout/login and confirm:

```bash
sudo -v
```

Why: you need admin rights to install packages, manage services, and configure networking.

---

## 2) Fix time issues before package installation

If `apt update` shows signature errors like `Not live until ...`, your VM clock is wrong.

```bash
su -
date -u
date -s "2026-07-02 23:50:00"   # set close to real current UTC time
hwclock --systohc
apt clean
apt update
```

Optional (recommended) time sync service:

```bash
apt install -y chrony
systemctl enable --now chrony
chronyc tracking
```

Why: repository signatures are time-sensitive; wrong clock breaks package validation.

---

## 3) Install required tools

```bash
sudo apt update
sudo apt install -y openssh-server docker.io docker-compose make
```

Notes:
- On some systems, `docker-compose-plugin` is unavailable.
- `docker-compose` package is fine for this project.

---

## 4) Start and enable services

```bash
sudo systemctl enable --now ssh docker
sudo systemctl status ssh docker --no-pager
```

Why: services should survive reboot and be active immediately.

---

## 5) Allow Docker without sudo

```bash
sudo usermod -aG docker $USER
```

Then **logout/login** once, and test:

```bash
docker ps
docker --version
docker compose version || docker-compose --version
```

Why: group membership is applied only after a new session.

---

## 6) VirtualBox network + SSH access

In VirtualBox:
- VM **Settings** -> **Network**
- Adapter 1 -> **Bridged Adapter**

Inside VM:

```bash
ip -4 a
```

From host machine:

```bash
ssh <your_user>@<vm_ip>
```

Why: Bridged mode gives your VM a LAN IP so host can connect directly via SSH.

---

## 7) Create mandatory Inception folder structure

```bash
mkdir -p ~/inception/{secrets,srcs/requirements/{mariadb,nginx,wordpress}/{conf,tools}}
mkdir -p /home/$USER/data/{mariadb,wordpress}
touch ~/inception/Makefile
touch ~/inception/srcs/.env ~/inception/srcs/docker-compose.yml
touch ~/inception/README.md ~/inception/USER_DOC.md ~/inception/DEV_DOC.md
```

Why:
- `srcs/` and root `Makefile` are mandatory.
- `/home/<login>/data/...` is where your two persistent named volumes must store host data.

---

## 8) Add local domain mapping

```bash
echo "127.0.0.1 $USER.42.fr" | sudo tee -a /etc/hosts
```

Why: project domain must be `<login>.42.fr`.

---

## 9) Prepare initial `.env` values

File: `~/inception/srcs/.env`

```env
DOMAIN_NAME=<yourlogin>.42.fr

MYSQL_DATABASE=wordpress
MYSQL_USER=wpuser
MYSQL_PASSWORD=change_me
MYSQL_ROOT_PASSWORD=change_me_root

WP_TITLE=inception
WP_ADMIN_USER=siteowner42
WP_ADMIN_PASSWORD=change_me_admin
WP_ADMIN_EMAIL=you@example.com

WP_USER=user42
WP_USER_PASSWORD=change_me_user
WP_USER_EMAIL=user42@example.com
```

Important:
- Do **not** use `admin` / `administrator` in WP admin username.
- Do **not** hardcode passwords in Dockerfiles.

---

## 10) Mandatory Inception rules checklist

- Use your own Dockerfiles (no prebuilt service images except base Debian/Alpine).
- No `latest` tag.
- NGINX must be the only entrypoint on port **443**.
- TLS must be **1.2/1.3 only**.
- 3 separate containers: `nginx`, `wordpress` (php-fpm), `mariadb`.
- 2 Docker **named volumes** mapped to `/home/<login>/data/...`.
- Include explicit custom docker network in compose.
- Restart policy enabled (e.g., `restart: always`).
- No `network: host`, `--link`, `links`.
- No infinite-loop entrypoint hacks (`tail -f`, `sleep infinity`, `while true`, etc.).

---

## 11) Fast troubleshooting

### A) `user is not in sudoers`
Use root once (`su -`) and run:

```bash
usermod -aG sudo <your_user>
```

### B) `Not live until` during `apt update`
Fix date/time (section 2), then rerun:

```bash
apt clean && apt update
```

### C) `Unable to locate package docker-compose-plugin`
Use:

```bash
apt install -y docker-compose
```

### D) `docker: permission denied`
Run:

```bash
sudo usermod -aG docker $USER
```

Then logout/login.

---

## 12) Next implementation phase

After this machine setup, implement:
1. `docker-compose.yml` with 3 services + network + named volumes.
2. Dockerfile + startup/init scripts for MariaDB.
3. Dockerfile + setup script for WordPress/php-fpm.
4. Dockerfile + TLS config for NGINX.
5. Makefile targets (`all`, `down`, `clean`, etc.).

