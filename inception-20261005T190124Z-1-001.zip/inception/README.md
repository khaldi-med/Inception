_This project has been created as part of the 42 curriculum by mohkhald._

# Inception Project

## Description

**Inception** is a system administration exercise that builds a complete virtualized infrastructure using Docker and Docker Compose. The project sets up a WordPress-based website powered by MariaDB and served through NGINX, all running in isolated containers on a virtual machine.

The goal is to understand containerization, networking, volume management, SSL/TLS configuration, and orchestration of multi-service applications using Docker best practices.

## Instructions

### Prerequisites
- A Virtual Machine (VirtualBox recommended)
- Debian/Alpine Linux with SSH enabled
- Docker and Docker Compose installed
- GNU Make

### Setup & Execution

1. **Clone or navigate to the project**
   ```bash
   cd /path/to/inception
   ```

2. **Configure environment variables**
   ```bash
   cp srcs/.env.example srcs/.env
   # Edit srcs/.env with your login and desired credentials
   ```

3. **Build and start services**
   ```bash
   make all
   ```

4. **Access the site**
   ```
   https://yourlogin.42.fr
   ```

5. **Manage the stack**
   ```bash
   make ps        # List running containers
   make logs      # Stream logs
   make down      # Stop services (keep volumes)
   make clean     # Remove containers and images
   make fclean    # Remove everything including data
   make re        # Full restart (fclean + all)
   ```

## Project Description

### Architecture Overview

The infrastructure consists of three microservices:

1. **NGINX** – Reverse proxy and web gateway (port 443 only, TLS)
2. **WordPress + php-fpm** – Application layer
3. **MariaDB** – Database layer

All services communicate via a custom Docker network. Data persists on the host machine in named volumes mapped to `/home/<login>/data/`.

### Key Technical Choices

- **Base Image**: Debian bookworm-slim (not `latest`)
- **Service Isolation**: Each service runs in its own container
- **Volume Strategy**: Named volumes with bind mounts to `/home/<login>/data/`
- **Networking**: Custom bridge network (no `network: host`, no `--link`)
- **Restart Policy**: `restart: always` for high availability
- **Process Management**: Services run as PID 1 (no `tail -f`, `sleep infinity`, or loops)

### Mandatory Comparisons

#### 1. Virtual Machines vs Docker

| Aspect | VM | Docker |
|--------|-----|--------|
| **Overhead** | Full OS per instance (~GBs) | Lightweight container (~MBs) |
| **Boot Time** | Seconds to minutes | Milliseconds to seconds |
| **Resource Isolation** | Full hardware isolation (hypervisor) | Process-level isolation (kernel) |
| **Use Case** | Legacy apps, multiple OS | Microservices, rapid scaling |
| **Portability** | Host-dependent | "Build once, run anywhere" |

#### 2. Secrets vs Environment Variables

| Aspect | Environment Variables | Docker Secrets |
|--------|--------|--------|
| **Storage** | Plaintext in `.env` or container env | Encrypted at rest (Docker Swarm) |
| **Access** | All processes in container see them | Only services that need them |
| **Rotation** | Manual or scripted restart | Dynamic (no restart needed) |
| **Security** | ⚠️ Lower (visible in ps, env) | ✓ Higher (hidden from env) |
| **Complexity** | Simple | Requires Docker Swarm or stack files |

**Decision**: This project uses `.env` for simplicity in development. Secrets are not hardcoded in Dockerfiles; passwords come from environment variables injected at runtime.

#### 3. Docker Network vs Host Network

| Aspect | Custom Network | Host Network |
|--------|--------|--------|
| **Isolation** | Services isolated from host | Services share host network stack |
| **Port Mapping** | Explicit (container port → host port) | None needed (uses host ports directly) |
| **DNS Resolution** | Automatic (service names = hostnames) | Manual hostname mapping |
| **Security** | Better (services hidden from host) | Risky (direct access) |
| **Performance** | Minimal overhead | Marginally faster (no translation) |

**Decision**: This project uses a custom `inception` bridge network. It enables service discovery by name (`mariadb`, `wordpress`, `nginx`) and provides security isolation.

#### 4. Docker Volumes vs Bind Mounts

| Aspect | Named Volume | Bind Mount |
|--------|--------|--------|
| **Management** | Docker manages (easier) | User manages (explicit) |
| **Path** | `/var/lib/docker/volumes/...` | User-specified directory |
| **Data Persistence** | Survives container removal | Survives container removal |
| **Portability** | Less portable (Docker-specific) | More portable (standard filesystem) |
| **Performance** | Optimized for Docker | Depends on mount type |
| **Dockerfile Reference** | Clean (volume name) | Requires host path knowledge |

**Decision**: This project uses named volumes with bind mount options to map data to `/home/<login>/data/`. This hybrid approach:
- Provides explicit host paths (visible for inspection/backup)
- Uses Docker's volume driver for consistency
- Allows easy data migration between machines

## Resources

### Docker & Containerization
- [Docker Official Documentation](https://docs.docker.com/)
- [Docker Compose Guide](https://docs.docker.com/compose/)
- [Best Practices for Dockerfiles](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)

### NGINX & TLS
- [NGINX Documentation](https://nginx.org/en/docs/)
- [Self-Signed SSL Certificates (OpenSSL)](https://www.ssl.com/how-to/openssl/)
- [TLS 1.2/1.3 Configuration](https://ssl-config.mozilla.org/)

### WordPress & php-fpm
- [WordPress Installation Guide](https://wordpress.org/support/article/how-to-install-wordpress/)
- [WP-CLI Documentation](https://wp-cli.org/)
- [PHP-FPM Configuration](https://www.php.net/manual/en/install.fpm.configuration.php)

### MariaDB
- [MariaDB Server Documentation](https://mariadb.com/docs/server/)
- [MariaDB Docker Guide](https://hub.docker.com/_/mariadb)

### System Administration
- [Linux System Administration Handbook](https://www.oreilly.com/library/view/linux-system-administration/9780136251324/)
- [Process Management & PID 1](https://www.fpcomplete.com/blog/docker-daemon-pid-1-exec/)

## AI Usage

This project leveraged AI assistance for:

1. **Initial Architecture Design**: Brainstorming multi-service layout, networking strategy, and volume management approach.
2. **Dockerfile Scaffolding**: Generating base Dockerfiles with best practices (slim images, no latest tags, proper entrypoints).
3. **Configuration File Generation**: Creating NGINX server blocks, php-fpm pool configurations, MariaDB settings.
4. **Script Development**: Writing init scripts for database seeding, WordPress setup, and SSL certificate generation.
5. **Makefile Creation**: Generating targets for build, orchestration, and cleanup.
6. **Documentation**: Drafting README sections, comparison tables, and troubleshooting guides.

**Critical Review Applied**: All generated code was reviewed for:
- Compliance with project constraints (no `latest`, no passwords, PID 1 adherence, no infinite loops)
- Security best practices (secrets handling, TLS configuration)
- Correctness (syntax, logic flow, error handling)
- Testing (manual verification on VM before deployment)

---

**For end-user instructions**: See `USER_DOC.md`  
**For developer setup**: See `DEV_DOC.md`
