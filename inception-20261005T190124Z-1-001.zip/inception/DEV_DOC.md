# DEV_DOC.md – Developer Documentation

## Overview

This document provides a step-by-step guide for developers to reproduce, modify, and extend the Inception infrastructure.

---

## Prerequisites

- **Host**: Linux/macOS with VirtualBox or similar VM hypervisor
- **VM OS**: Debian bookworm-slim or Alpine (penultimate stable)
- **Tools Installed**: Docker, Docker Compose, Make, Git
- **Network**: Bridged adapter so host can SSH into VM
- **Ports Available**: 443 (HTTPS)

### Initial VM Setup

See `SCHOOL_VM_SETUP.md` for detailed VM bootstrap instructions.

Quick summary:
```bash
sudo apt update
sudo apt install -y docker.io docker-compose make openssh-server git
sudo systemctl enable --now docker ssh
sudo usermod -aG docker $USER
# Logout/login once
git clone <repo> ~/inception
cd ~/inception
```

---

## Project Structure

```
inception/
├── Makefile                          # Build & orchestration targets
├── README.md                         # Project overview & design
├── USER_DOC.md                       # End-user guide
├── DEV_DOC.md                        # This file
├── SCHOOL_VM_SETUP.md                # VM bootstrap instructions
├── .gitignore                        # Git exclusions (secrets/, .env)
├── secrets/                          # Docker secrets (local, ignored by git)
└── srcs/
    ├── .env                          # Environment variables (IGNORED by .gitignore)
    ├── .env.example                  # Template for .env
    ├── docker-compose.yml            # Service orchestration
    └── requirements/
        ├── mariadb/
        │   ├── Dockerfile            # Database image
        │   ├── .dockerignore
        │   ├── conf/
        │   │   └── 50-server.cnf     # MariaDB config
        │   └── tools/
        │       └── init-mariadb.sh   # Database initialization
        ├── wordpress/
        │   ├── Dockerfile            # Application image
        │   ├── .dockerignore
        │   ├── conf/
        │   │   └── www.conf          # PHP-FPM pool config
        │   └── tools/
        │       └── setup-wordpress.sh # WordPress + site setup
        └── nginx/
            ├── Dockerfile            # Web gateway image
            ├── .dockerignore
            ├── conf/
            │   └── default.conf      # NGINX server config
            └── tools/
                └── start-nginx.sh    # TLS cert + startup
```

---

## Setup from Scratch

### 1. Clone and Navigate
```bash
git clone <repo-url> ~/inception
cd ~/inception
```

### 2. Create Environment File

```bash
cp srcs/.env.example srcs/.env
```

Edit `srcs/.env` with your values:
```env
LOGIN=yourlogin                        # Your system username
DOMAIN_NAME=yourlogin.42.fr            # Your project domain
MYSQL_DATABASE=wordpress
MYSQL_USER=wpuser
MYSQL_PASSWORD=choose_a_strong_password
MYSQL_ROOT_PASSWORD=choose_a_strong_password
WP_TITLE=Your Site Title
WP_ADMIN_USER=siteowner_name           # NOT "admin" or "administrator"
WP_ADMIN_PASSWORD=choose_a_strong_password
WP_ADMIN_EMAIL=admin@example.com
WP_USER=user_name
WP_USER_PASSWORD=choose_a_strong_password
WP_USER_EMAIL=user@example.com
```

### 3. Ensure Host Data Directories

```bash
mkdir -p /home/$USER/data/{mariadb,wordpress}
```

These must exist before `docker-compose up`.

### 4. Build and Start Services

```bash
make all
```

Logs will stream. Press `Ctrl+C` to detach (containers keep running in background).

### 5. Verify Deployment

```bash
make ps
docker network ls | grep inception
docker volume ls | grep -E "mariadb_data|wordpress_data"
```

### 6. Test Connectivity

From **inside the VM**:
```bash
curl -k https://localhost
```

From **host machine**:
```bash
curl -k https://yourlogin.42.fr
```

Expected: HTML response (WordPress homepage or setup screen).

---

## Build Process Explained

### Makefile Targets

| Target | Action |
|--------|--------|
| `make all` | Build images & start services in detached mode |
| `make up` | Alias for `all` |
| `make down` | Stop services (keep volumes) |
| `make clean` | Remove containers + images (keep volumes) |
| `make fclean` | Full reset (remove volumes too) |
| `make re` | `fclean` + `all` |
| `make logs` | Stream container logs |
| `make ps` | List running containers |

### Build Flow

1. **Makefile** calls `docker-compose up --build -d`
2. **docker-compose** reads `srcs/docker-compose.yml`
3. **docker-compose** builds 3 images from Dockerfiles:
   - `mariadb` (from `srcs/requirements/mariadb/Dockerfile`)
   - `wordpress` (from `srcs/requirements/wordpress/Dockerfile`)
   - `nginx` (from `srcs/requirements/nginx/Dockerfile`)
4. **docker-compose** creates named volumes + custom network
5. **docker-compose** starts containers with dependencies (`nginx` waits for `wordpress`, `wordpress` waits for `mariadb`)

### First Startup Sequence

1. **MariaDB starts first**
   - `init-mariadb.sh` initializes database (creates DB, user, sets passwords)
   - Runs `mysqld --console` in foreground

2. **WordPress starts** (depends_on mariadb)
   - `setup-wordpress.sh` waits for MariaDB to be ready
   - Downloads & configures WordPress
   - Installs plugins, creates admin + secondary users
   - Runs `php-fpm8.2 -F` in foreground

3. **NGINX starts** (depends_on wordpress)
   - `start-nginx.sh` generates self-signed SSL cert
   - Configures TLS 1.2/1.3
   - Sets up reverse proxy to wordpress:9000
   - Runs `nginx -g "daemon off;"` in foreground

---

## Configuration Files

### docker-compose.yml

Key sections:
- **services**: mariadb, wordpress, nginx
- **networks**: inception (custom bridge network)
- **volumes**: mariadb_data, wordpress_data (bind mounts to `/home/$LOGIN/data/`)
- **depends_on**: Service startup order
- **env_file**: Loads variables from `srcs/.env`
- **restart**: always (auto-restart on crash)

### Dockerfiles

**Principles**:
- Use Debian bookworm-slim (not `latest`)
- Install only necessary packages
- Remove apt cache to shrink image size
- Copy configs and scripts
- Run processes in foreground (PID 1)
- Use explicit ENTRYPOINT scripts (not /bin/sh)

**Example (MariaDB)**:
```dockerfile
FROM debian:bookworm-slim
RUN apt-get update && apt-get install -y ... && rm -rf /var/lib/apt/lists/*
COPY conf/ tools/
RUN chmod +x /usr/local/bin/init-mariadb.sh
ENTRYPOINT ["/usr/local/bin/init-mariadb.sh"]
```

### Entrypoint Scripts

All services run custom scripts that:
1. **Validate** required environment variables
2. **Initialize** (database seed, WordPress install, SSL cert)
3. **Exec** the main process (mysqld, php-fpm, nginx)

Uses `exec` so the main process takes over PID 1 (no zombie process issues).

---

## Modification & Extension Guide

### Change WordPress Theme

```bash
make ps
docker exec -it wordpress wp theme install twentytwentyfour --allow-root
docker exec -it wordpress wp theme activate twentytwentyfour --allow-root
```

### Install WordPress Plugin

```bash
docker exec -it wordpress wp plugin install jetpack --allow-root
docker exec -it wordpress wp plugin activate jetpack --allow-root
```

### Access Database Directly

```bash
docker exec -it mariadb mariadb -u root -p
# Enter MYSQL_ROOT_PASSWORD
```

### Check NGINX Config

```bash
docker exec -it nginx nginx -T
```

### Rebuild Specific Service

```bash
docker-compose -f srcs/docker-compose.yml --env-file srcs/.env up -d --build nginx
```

### Add Redis Cache (Bonus)

1. Create `srcs/requirements/redis/Dockerfile`
2. Add redis service to `docker-compose.yml`
3. Update NGINX config to cache

### Add FTP Server (Bonus)

1. Create `srcs/requirements/ftp/Dockerfile`
2. Mount `/var/www/html` read-write
3. Expose port 21/20

---

## Debugging

### Service Logs

```bash
docker-compose -f srcs/docker-compose.yml --env-file srcs/.env logs -f <service>
```

Services: `mariadb`, `wordpress`, `nginx`

### Enter Container Shell

```bash
docker exec -it <container_name> /bin/bash
# or /bin/sh for minimal images
```

### Check Network

```bash
docker network inspect inception
```

Shows all containers connected and their IPs.

### Check Volumes

```bash
docker volume inspect mariadb_data
docker volume inspect wordpress_data
```

Shows mount paths on host.

### Test HTTPS Certificate

```bash
openssl s_client -connect localhost:443 -showcerts
```

Verify certificate details and TLS version.

---

## Common Issues & Fixes

### Issue: Port 443 Already in Use

**Symptom**: NGINX fails to start.

**Fix**:
```bash
sudo lsof -i :443
# Kill the process or change NGINX port in docker-compose.yml
```

### Issue: Database Won't Initialize

**Symptom**: WordPress stuck waiting for DB, logs show connection errors.

**Fix**:
```bash
docker logs mariadb
# Check MYSQL_PASSWORD, MYSQL_ROOT_PASSWORD match compose env
make fclean  # Full reset
make all     # Rebuild
```

### Issue: WordPress File Permissions

**Symptom**: Can't upload files, 403 errors.

**Fix**:
```bash
sudo chown -R $USER:$USER /home/$USER/data/wordpress
```

### Issue: Self-Signed Certificate Not Trusting

**Symptom**: Browser warns about untrusted certificate.

**Expected behavior**. Import the cert into your trusted store:
```bash
openssl x509 -in /home/$USER/data/nginx/inception.crt -text -noout
# Then add to browser/OS trust store (varies by OS)
```

---

## Deployment Checklist

Before pushing to production-like environment:

- [ ] All environment variables set in `srcs/.env`
- [ ] WP_ADMIN_USER does NOT contain "admin" or "administrator"
- [ ] Passwords are strong (min 12 chars, mixed case, numbers, symbols)
- [ ] `.env` is in `.gitignore` (never commit credentials)
- [ ] `make all` succeeds without errors
- [ ] All three services running: `make ps`
- [ ] HTTPS accessible: `curl -k https://yourlogin.42.fr`
- [ ] WordPress admin login works
- [ ] Database persists after `make down` → `make all`
- [ ] Reboot test: Reboot VM, run `make all`, verify stack works

---

## Resources for Developers

- **Docker Docs**: https://docs.docker.com/
- **Docker Compose**: https://docs.docker.com/compose/compose-file/
- **MariaDB Docker Image**: https://hub.docker.com/_/mariadb
- **Debian Packages**: https://packages.debian.org/
- **NGINX Config**: https://nginx.org/en/docs/
- **PHP-FPM**: https://www.php.net/manual/en/install.fpm.php
- **OpenSSL**: https://www.openssl.org/docs/
- **WP-CLI**: https://wp-cli.org/

---

## Questions or Issues?

Refer to:
- `README.md` for project overview
- `USER_DOC.md` for end-user instructions
- `INCEPTION_GUIDE.md` for high-level phasing
- `subject.md` for official requirements
