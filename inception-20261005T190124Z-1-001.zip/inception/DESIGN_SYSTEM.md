# Wrote DESIGN_SYSTEM.md
# Clothing E-commerce Design System
## Luxury Fashion Direction

### Inspiration References
- **Gucci / Balenciaga**: Dark mode default, serif display fonts, gold accents
- **SSENSE**: Minimal navigation, editorial product grids, subtle animations
- **Farfetch**: Premium feel, layered shadows, sophisticated typography
- **The Row / Loro Piana**: Quiet luxury, texture over logo, refined restraint

---

## Color System

### Primary Palette (Dark Luxury)
```css
/* Core Brand - Deep Charcoal/Black base with warm gold accent */
--color-bg-primary: #0a0a0a;        /* Near black */
--color-bg-secondary: #141414;      /* Elevated surfaces */
--color-bg-tertiary: #1e1e1e;       /* Cards, inputs */
--color-bg-hover: #262626;          /* Interactive hover */

--color-text-primary: #fafafa;      /* Pure white */
--color-text-secondary: #d4d4d4;    /* Muted white */
--color-text-muted: #a3a3a3;        /* Subtle labels */
--color-text-inverse: #0a0a0a;      /* On gold */

--color-gold-50: #fefce8;
--color-gold-100: #fef9c3;
--color-gold-200: #fef08a;
--color-gold-300: #fde047;
--color-gold-400: #facc15;
--color-gold-500: #eab308;          /* Primary accent */
--color-gold-600: #ca8a04;
--color-gold-700: #a16207;
--color-gold-800: #854d0e;
--color-gold-900: #713f12;

/* Semantic */
--color-success: #16a34a;
--color-warning: #facc15;
--color-error: #dc2626;
--color-info: #2563eb;
```

### Light Mode (Optional)
```css
--color-bg-primary: #fafafa;
--color-bg-secondary: #ffffff;
--color-bg-tertiary: #f5f5f5;
--color-text-primary: #0a0a0a;
--color-text-secondary: #404040;
--color-text-muted: #737373;
--color-gold-500: #a16207;
```

---

## Typography

### Font Families
```css
/* Display - Editorial serif for headlines */
--font-display: 'Fraunces', 'Playfair Display', serif;

/* Body - Clean, readable sans */
--font-body: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;

/* Mono - SKU, prices, technical */
--font-mono: 'JetBrains Mono', 'SF Mono', monospace;

/* Arabic - Noto Sans Arabic for RTL */
--font-arabic: 'Noto Sans Arabic', 'Cairo', sans-serif;
```

### Type Scale (Fluid, clamp-based)
| Token | Mobile | Desktop | Usage |
|-------|--------|---------|-------|
| `--text-display-xl` | clamp(2.5rem, 5vw, 4.5rem) | clamp(3.5rem, 4vw, 6rem) | Hero headlines |
| `--text-display-lg` | clamp(2rem, 4vw, 3.5rem) | clamp(2.5rem, 3vw, 4rem) | Page titles |
| `--text-display-md` | clamp(1.5rem, 3vw, 2.5rem) | clamp(2rem, 2.5vw, 3rem) | Section headers |
| `--text-display-sm` | clamp(1.25rem, 2.5vw, 1.75rem) | clamp(1.5rem, 2vw, 2rem) | Card titles |
| `--text-heading-xl` | 2rem | 2.5rem | Major headings |
| `--text-heading-lg` | 1.5rem | 1.75rem | Section headings |
| `--text-heading-md` | 1.25rem | 1.375rem | Subsection headings |
| `--text-heading-sm` | 1rem | 1.125rem | Small headings |
| `--text-body-lg` | 1.125rem | 1.125rem | Lead paragraphs |
| `--text-body-md` | 1rem | 1rem | Default body |
| `--text-body-sm` | 0.875rem | 0.875rem | Secondary text |
| `--text-caption` | 0.75rem | 0.75rem | Labels, meta |
| `--text-micro` | 0.625rem | 0.625rem | Legal, badges |

### Font Weights
- `--font-light`: 300 (Display only)
- `--font-regular`: 400
- `--font-medium`: 500
- `--font-semibold`: 600
- `--font-bold`: 700

### Line Heights
- `--leading-tight`: 1.1 (Display)
- `--leading-snug`: 1.3 (Headings)
- `--leading-normal`: 1.6 (Body)
- `--leading-relaxed`: 1.8 (Long-form)

### Letter Spacing
- `--tracking-tighter`: -0.02em (Display)
- `--tracking-tight`: -0.01em (Headings)
- `--tracking-normal`: 0 (Body)
- `--tracking-wide`: 0.02em (Captions)
- `--tracking-wider`: 0.1em (Uppercase UI)
- `--tracking-widest`: 0.2em (Letter-spaced labels)

---

## Spacing System (4px Base)

| Token | Value | Usage |
|-------|-------|-------|
| `--space-0` | 0 | Reset |
| `--space-1` | 4px | Micro gaps |
| `--space-2` | 8px | Compact |
| `--space-3` | 12px | Tight |
| `--space-4` | 16px | Base unit |
| `--space-5` | 20px | Comfortable |
| `--space-6` | 24px | Section inner |
| `--space-8` | 32px | Component gaps |
| `--space-10` | 40px | Section gaps |
| `--space-12` | 48px | Large sections |
| `--space-16` | 64px | Page sections |
| `--space-20` | 80px | Hero padding |
| `--space-24` | 96px | Major breaks |

### Responsive Spacing
```css
--space-section-y: clamp(48px, 8vw, 96px);
--space-container-x: clamp(16px, 4vw, 32px);
```

---

## Border Radius

| Token | Value |
|-------|-------|
| `--radius-none` | 0 |
| `--radius-sm` | 4px |
| `--radius-md` | 8px |
| `--radius-lg` | 12px |
| `--radius-xl` | 16px |
| `--radius-2xl` | 24px |
| `--radius-full` | 9999px |

---

## Shadows & Elevation

| Level | Box Shadow | Usage |
|-------|------------|-------|
| `--shadow-0` | none | Flat |
| `--shadow-1` | 0 1px 2px rgba(0,0,0,0.3) | Cards rest |
| `--shadow-2` | 0 4px 8px rgba(0,0,0,0.35) | Cards hover |
| `--shadow-3` | 0 8px 24px rgba(0,0,0,0.4) | Dropdowns, modals |
| `--shadow-4` | 0 16px 48px rgba(0,0,0,0.45) | Drawers, sheets |
| `--shadow-5` | 0 24px 64px rgba(0,0,0,0.5) | Full-screen modals |
| `--shadow-gold` | 0 0 0 1px var(--color-gold-500) | Focus rings |
| `--shadow-inner` | inset 0 2px 4px rgba(0,0,0,0.2) | Inputs |

---

## Motion & Animation

### Durations
| Token | Value | Usage |
|-------|-------|-------|
| `--duration-instant` | 0ms | Immediate |
| `--duration-fast` | 150ms | Micro-interactions |
| `--duration-normal` | 250ms | Transitions |
| `--duration-slow` | 350ms | Modals, drawers |
| `--duration-slower` | 500ms | Page transitions |

### Easings
| Token | Value | Usage |
|-------|-------|-------|
| `--ease-linear` | linear | Spinners |
| `--ease-out` | cubic-bezier(0, 0, 0.2, 1) | Standard exits |
| `--ease-in` | cubic-bezier(0.4, 0, 1, 1) | Standard entries |
| `--ease-in-out` | cubic-bezier(0.4, 0, 0.2, 1) | Most transitions |
| `--ease-spring` | cubic-bezier(0.34, 1.56, 0.64, 1) | Playful, bouncy |
| `--ease-luxury` | cubic-bezier(0.16, 1, 0.3, 1) | Premium, smooth |

---

## Breakpoints

| Token | Value |
|-------|-------|
| `--bp-xs` | 320px |
| `--bp-sm` | 640px |
| `--bp-md` | 768px |
| `--bp-lg` | 1024px |
| `--bp-xl` | 1280px |
| `--bp-2xl` | 1536px |

---

## Z-Index Scale

| Layer | Value |
|-------|-------|
| `--z-base` | 0 |
| `--z-dropdown` | 100 |
| `--z-sticky` | 200 |
| `--z-fixed` | 300 |
| `--z-drawer` | 400 |
| `--z-modal` | 500 |
| `--z-popover` | 600 |
| `--z-tooltip` | 700 |
| `--z-toast` | 800 |

---

## Component Specifications

### Button
```tsx
// Variants: primary, secondary, outline, ghost, link
// Sizes: sm, md, lg, xl
// States: default, hover, active, disabled, loading

Primary:      bg=gold-500, color=text-inverse, hover=gold-600
Secondary:    bg=bg-tertiary, color=text-primary, hover=bg-hover
Outline:      border=gold-500, color=gold-500, hover=bg-gold-500/10
Ghost:        transparent, color=text-secondary, hover=bg-tertiary
Link:         transparent, color=gold-500, underline hover
```

### Input
```tsx
// States: default, focus, error, disabled, filled
// Sizes: sm, md, lg

Container:    bg=bg-tertiary, border=transparent
Focus:        border=gold-500, shadow=shadow-gold
Error:        border=error, focus:border=error
Label:        text-caption, uppercase, tracking-wider, color=text-muted
Placeholder:  color=text-muted
Helper:       text-caption, color=text-muted/error
```

### Card (Product)
```tsx
// Structure: Image wrapper (aspect-ratio 3:4), Content, Actions
// Hover: translateY(-4px), shadow-3, image scale(1.03)
// Badges: Sale (red), New (gold), Featured (gold outline)
// Quick actions: Wishlist, Quick view (appear on hover)
```

### Modal / Drawer
```tsx
// Backdrop: rgba(0,0,0,0.6), backdrop-blur-sm
// Container: bg=bg-secondary, border=1px solid rgba(255,255,255,0.05)
// Close: top-right, ghost button, hover:bg-tertiary
// Animation: fade + slide up (drawer), fade + scale (modal)
```

### Form Elements
- **Select**: Native-styled with custom arrow, matches Input
- **Checkbox/Radio**: Gold accent, custom SVG check
- **Switch**: Gold thumb, dark track
- **Slider**: Gold track, gold thumb

### Navigation
- **Navbar**: Fixed, backdrop-blur, border-bottom on scroll
- **Mega Menu**: Gold accent lines, columnar layout
- **Breadcrumbs**: Micro text, gold separator, truncated
- **Pagination**: Minimal, current page gold

### Data Display
- **Table**: Striped rows, hover highlight, sticky header
- **Badge**: Pill, gold for primary, muted for secondary
- **Tag**: Rounded, outline variant
- **Avatar**: Gold border on hover, status indicator

---

## RTL Adaptations (Arabic)

### Layout Mirroring
- Flex direction: `row-reverse` for horizontal layouts
- Margin/Padding: Logical properties (`margin-inline-start`)
- Text alignment: `start`/`end` instead of `left`/`right`
- Position: `inset-inline-start`/`inset-inline-end`

### Components Requiring RTL
- Navbar (logo right, actions left)
- Breadcrumbs (reversed)
- Pagination (reversed)
- Form labels (right-aligned)
- Select dropdown (right-aligned)
- Modal actions (reversed)
- Cart drawer (slides from left)
- Tooltips (flipped)

### Arabic Typography
```css
[dir="rtl"] {
  --font-body: var(--font-arabic);
  --font-display: var(--font-arabic);
  font-feature-settings: 'liga' 1, 'calt' 1;
}
```

---

## Accessibility

### Color Contrast (WCAG AA)
- Text on bg-primary: 15.8:1 ✓
- Gold on bg-primary: 4.5:1 ✓ (large text)
- Gold on bg-secondary: 3.8:1 ⚠ (use gold-400 for body)
- Muted text: 3.2:1 ⚠ (use for non-essential only)

### Focus Management
- Visible focus rings on all interactive elements
- Skip to main content link
- Focus trap in modals/drawers
- Restore focus on close

### Screen Readers
- Semantic HTML5 landmarks
- ARIA labels on icon-only buttons
- Live regions for toasts/cart updates
- Proper heading hierarchy (h1-h6)

---

## Implementation Notes

### CSS Variables Strategy
```css
:root {
  /* All tokens as CSS custom properties */
  --color-bg-primary: #0a0a0a;
  /* ... */
}

[data-theme="light"] {
  /* Light mode overrides */
}

[dir="rtl"] {
  /* RTL overrides */
}
```

### Chakra UI Integration
- Extend theme with all tokens
- Create custom components wrapping Chakra primitives
- Use `styleProps` for consistent API
- Leverage Chakra's `useColorMode` for dark/light

### Component Library Structure
```
src/design-system/
├── theme/
│   ├── tokens.ts          # All design tokens
│   ├── theme.ts           # Chakra theme extension
│   └── globalStyles.ts    # CSS reset, global styles
├── components/
│   ├── Button/
│   ├── Input/
│   ├── Card/
│   ├── Modal/
│   ├── Select/
│   ├── Badge/
│   ├── Avatar/
│   ├── Typography/
│   └── index.ts
├── hooks/
│   ├── useColorMode.ts
│   ├── useMediaQuery.ts
│   └── useRTL.ts
├── utils/
│   ├── cx.ts              # Classnames utility
│   └── formatters.ts
└── index.ts
```
